# Country-level expansion of Table 2 (Supplementary Table S3)

This release adds three CSVs to the eighteen existing supplementary CSVs.
The selected file contains 30 countries/regions ranked by 2018 observed AI
output credits. The endpoint file contains all 210 country/region codes;
the annual file contains 1,470 country-year rows for 2018–2024.

All use the Table 2 primary specification: conservative country mapping,
whole-count first-listed-author accepted credits, and whole-count all-author
OpenAlex AI country output credits (subfield 1702; article/conference-paper).
Shares use the complete observed annual country-credit totals, including
countries outside the displayed 30. PRI = accepted share / output share.
Zero observed output shares produce a blank PRI and an explicit status.
Missing country-year rows represent zero credits in the preserved snapshot,
rather than a claim of zero actual production. NA is the code for Namibia;
retain it as a string (e.g. keep_default_na=False in pandas).
Jersey (JE), present only in the numerator, is retained with undefined PRI.
Credits are not unique-paper counts, and countries denote affiliation location.
No missingness-bound flags from the other denominator are transferred.

Existing CSVs, mapping, and figure-data entries are preserved byte for byte.
No new API query or individual-level model fitting was performed.

Supplementary Table S3 is included in Additional file 2, Supplementary_Table_S3.csv.
