# Source provenance and limits

The code version is Git commit 24f135413f203c56494a9c7b1388ce250f23b395. Code uses Python 3.11 on Linux under MIT; upstream data retain their own terms. Dependencies and source workflows are documented in the project repository.

OpenAlex country-level queries were collected on 11 August 2026. All 21 retained responses are in preserved_openalex_country_api/. They support the 12 aggregate-based specifications. The 863,752-record work-level intermediate is not preserved: the other 32 specifications and role-matched endpoints survive as frozen aggregate results, not as fully reconstructible model inputs.

DBLP conference XML records were retrieved on 31 July 2026. The exact full-dump retrieval date and matching monthly release are not established. The retained dump has SHA-256 158c35460ae2f39bcc29ca6d12ee77c28cbf7b24835a047dd5ae40111e7dbd1f. Its gzip internal timestamp is 28 July 2026; this does not establish the retrieval date or identify an official monthly snapshot.

ETO Country AI Activity Metrics v1.11.0 is identified by DOI 10.5281/zenodo.19103157. This is the ETO source dataset DOI, not an archive DOI for this study. SPECTER2 base and adapter names are known, but immutable model revisions were not recorded.

No individual author–paper links, names, affiliations, embeddings, or pilot rows are redistributed here. Queries issued later against mutable sources may yield different records. None of these packaging or typography changes refits a model or changes a frozen estimate.
