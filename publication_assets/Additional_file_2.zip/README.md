# Additional file 2: machine-readable data and analysis protocols

This archive combines the previous data-table ZIP, frozen protocol/configuration/QA ZIP, and country-level Supplementary Table S3. Additional file 1 is the accompanying supplementary PDF. Upload only the two files Additional_file_1.pdf and Additional_file_2.zip; the former Additional files 3 and 4 are included here.

- tables/: five original table CSVs. Their mapping to the six manuscript tables is in main_table_source_mapping.csv.
- additional_files/: 21 supplementary CSVs, including Supplementary_Table_S3.csv (30 countries/regions), the full 210-code endpoint file, and all 1,470 annual country-year rows.
- figure_data/: frozen Figure 2 and supplementary Figure S3 inputs.
- protocols/, configurations/, qa/: unchanged original frozen documents and diagnostics.
- preserved_openalex_country_api/: all 21 preserved API responses.
- documentation/: full provenance and remaining reproduction limits, moved out of the manuscript.

All original CSV names, bytes, estimates and intervals are unchanged. CSV shares are proportions, not percentages. The S3 country selection is ordered by 2018 observed AI output credits; its country selection and endpoint values are unchanged.

## Detailed original table mapping

# Frozen tables and current numbering

This ZIP contains five original main-table CSVs (tables/), twenty-one supplementary
CSV datasets (additional_files/), and main_table_source_mapping.csv.
The current manuscript has six main tables: Table 3(a-b) relocates frozen supplementary
CSV S10; Table 5(c) relocates semantic_primary results from supplementary CSV S5.
Frozen CSV bytes, filenames, and estimates are unchanged.

table_s10b_restricted_missingness_bounds.csv (Table 3c) is the restricted-missingness CSV added in v06.
It is not a new data collection. Observed group shares, accepted shares, and annual
missingness rates are reconstructed from frozen CSV S10 and re-verified against it:
delta = 0 reproduces the observed endpoint change and delta = 1 reproduces the frozen
worst-case bound. No OpenAlex query was re-run.
Four figure-data CSVs provide the plot inputs for the three-panel Figure 2 and for
Figure S3. They supersede the two-panel Figure 2 inputs shipped with v05 and are
separate from the 5+21 tables.

IMPORTANT: table_2_geographic_endpoints.csv retains the legacy field
direction_identified_under_denominator_missingness_bounds. Do not interpret that
field as a missingness verdict for the primary all-authorship country API PRI.
Current Table 2 omits it. Table 3 and CSV S10 distinguish fractional and full
numerators under the separate strict first-position fractional denominator.
China is sign-identified only in the fractional-numerator denominator-only case;
the full-numerator bound spans zero. Separate numerator-only bounds allow reversal.
Neither analysis jointly varies both sources of missingness.

The mapping also references qa/sample_flow_rq3.csv for the intermediate N=5207.
That diagnostic is in the full source bundle, not among the 5+17 frozen CSVs.

Work-level provenance: the 863,752-record work-level intermediate that produced the
32 work-level specifications and the role-matched denominators is not preserved.
Its results survive only as frozen values in table_s9_pri_specification_dashboard.csv,
which is why the manuscript reports the role-matched specification as a 2018/2024
endpoint sensitivity rather than as an annual trajectory.

See additional_files/README_country_detail.md for the three country-level CSVs added with Supplementary Table S3.
