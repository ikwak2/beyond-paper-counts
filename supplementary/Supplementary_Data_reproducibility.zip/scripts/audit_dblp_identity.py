#!/usr/bin/env python3
"""New provenance audit; no model fitting and no public redistribution of linked input rows."""
from pathlib import Path
import sys,importlib.util,hashlib,json,pandas as pd,subprocess
import argparse
parser=argparse.ArgumentParser(description="Reparse retained DBLP inputs and check original cohort hashes; requires local row-level sources, not distributed in the public bundle.")
parser.add_argument('--top-ai-root',type=Path,required=True)
parser.add_argument('--analysis-root',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args()
TOP=args.top_ai_root;GEO=args.analysis_root;OUT=args.output_dir;OUT.mkdir(parents=True,exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
spec=importlib.util.spec_from_file_location('dblp_intake',TOP/'scripts/01_download_dblp.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from top_ai_entry.metrics import mark_newcomers
from top_ai_entry.common import normalize_author_name
manifest=json.loads((TOP/'data/raw/dblp/provenance.json').read_text())
papers=[];authors=[];raw_checks=[]
for row in manifest['snapshots']:
 p=TOP/row['local_file'];rp,ra=m.parse_dblp_xml(p,row['venue'],row['year']);papers.extend(rp);authors.extend(ra)
 raw_checks.append({'path':row['local_file'],'venue':row['venue'],'year':row['year'],'records':len(rp),'authorships':len(ra),'sha256':sha(p),'recorded_sha256':row['sha256'],'hash_matches':sha(p)==row['sha256'],'source_url_recorded':row['source_url'],'recorded_timestamp':row['retrieved_at']})
a=pd.DataFrame(authors);p=pd.DataFrame(papers)
a0=a.copy();p0=p.copy();a=a.drop_duplicates(['paper_key','author_order']);p=p.drop_duplicates('paper_key')
saved_a=pd.read_csv(TOP/'data/processed/accepted_authorships_dblp.csv',keep_default_na=False)
saved_p=pd.read_csv(TOP/'data/processed/accepted_papers_dblp.csv',keep_default_na=False)
marked=pd.read_csv(TOP/'data/processed/accepted_authorships_marked.csv',keep_default_na=False)
def compare(left,right,cols,sort):
 l=left[cols].sort_values(sort).reset_index(drop=True).astype(str);r=right[cols].sort_values(sort).reset_index(drop=True).astype(str)
 return {'left_rows':len(l),'right_rows':len(r),'equal':l.equals(r),'mismatch_cells':int(l.ne(r).sum().sum()) if l.shape==r.shape else None}
checks={'raw_vs_processed_authors':compare(a,saved_a,list(a.columns),['paper_key','author_order']),'raw_vs_processed_papers':compare(p,saved_p,list(p.columns),['paper_key']),'processed_vs_marked_identity_fields':compare(saved_a,marked,list(a.columns),['paper_key','author_order'])}
rebuilt_marked=mark_newcomers(saved_a,lookback_years=5)
checks['newcomer_flags']=compare(rebuilt_marked,marked,['paper_key','author_order','top4_newcomer_5y','venue_newcomer_5y'],['paper_key','author_order'])
scopes=[]
for name,sub in [('all_saved_2013_2025',saved_a),('four_venue_history_2013_2024',saved_a[saved_a.year.between(2013,2024)]),('focal_2018_2024',saved_a[saved_a.year.between(2018,2024)&saved_a.venue.isin(['ICML','NeurIPS'])])]:
 for role,df in [('all_positions',sub),('first_listed',sub[sub.author_order.eq(1)])]:
  scopes.append({'scope':name,'role':role,'paper_count':df.paper_key.nunique(),'authorship_rows':len(df),'pid_nonempty':int(df.author_pid.ne('').sum()),'pid_empty':int(df.author_pid.eq('').sum()),'unique_pids':df.loc[df.author_pid.ne(''),'author_pid'].nunique(),'unique_name_strings':df.author_name.nunique(),'normalized_name_identity_rows':int(df.identity_source.eq('normalized_name').sum())})
scope=marked[marked.year.between(2018,2024)&marked.venue.isin(['ICML','NeurIPS'])]
first=scope[scope.author_order.eq(1)&scope.top4_newcomer_5y.eq(True)]
stable=first[first.identity_source.eq('dblp_pid')&first.author_pid.ne('')&first.author_key.ne('')].copy()
stable['earliest_year']=stable.groupby('author_key').year.transform('min');kept=stable[stable.year.eq(stable.earliest_year)]
cohort_path=GEO/'outputs/epj_distance_based_v10/private/epj_distance_full_entrant_cohort_private.csv'
cohort=pd.read_csv(cohort_path,keep_default_na=False)
cohort_keys=set(zip(cohort.author_key,cohort.index_year));rebuilt_keys=set(zip(kept.author_key,kept.year))
retained=json.loads((GEO/'outputs/epj_distance_based_v10/manifests/epj_distance_full_cohort_diagnostics.json').read_text())
hash_checks=[]
for bucket in ['input_sha256','output_sha256']:
 for name,old in retained[bucket].items():
  file=TOP/name.split('bibliometrics/top_ai_entry/',1)[1] if 'bibliometrics/top_ai_entry/' in name else GEO/name
  hash_checks.append({'kind':bucket,'path':name,'exists':file.exists(),'recorded_sha256':old,'current_sha256':sha(file) if file.exists() else None,'matches':file.exists() and sha(file)==old})
script_hashes={str(p):sha(p) for p in [TOP/'scripts/01_download_dblp.py',TOP/'scripts/03_build_baseline.py',TOP/'src/top_ai_entry/common.py',TOP/'src/top_ai_entry/metrics.py',GEO/'scripts/81_build_epj_distance_full_cohort.py',GEO/'scripts/82_scan_epj_distance_full_dblp_histories.py']}
versions={}
for q in [TOP,GEO]:
 r=subprocess.run(['git','-C',str(q),'rev-parse','HEAD'],capture_output=True,text=True);versions[str(q)]=r.stdout.strip() if r.returncode==0 else 'not a Git checkout'
result={'scope_counts':scopes,'raw_file_hashes_verified':sum(x['hash_matches'] for x in raw_checks),'raw_file_count':len(raw_checks),'parsing_checks':checks,'raw_duplicate_authorship_rows_removed':len(a0)-len(a),'raw_duplicate_paper_rows_removed':len(p0)-len(p),'cohort_checks':{'qualifying_first_authorships':len(first),'stable_pid_qualifying_first_authorships':len(stable),'excluded_missing_pid':len(first)-len(stable),'first_year_index_authorships':len(kept),'later_qualifying_authorship_rows_not_retained':len(stable)-len(kept),'unique_retained_pids':kept.author_pid.nunique(),'retained_cohort_person_year_keys_equal':cohort_keys==rebuilt_keys,'nonqualifying_first_authorship_rows':len(scope[scope.author_order.eq(1)])-len(first)},'retained_run_hash_checks':hash_checks,'source_code_current_sha256':script_hashes,'git_head_observed_now':versions,'limits':['Raw conference XML PIDs are DBLP-supplied identities, not an independent identity-accuracy audit.','A fresh reparse is an audit run; it is not an original collection log.','Cached provenance timestamps are processing timestamps, not proof of initial HTTP retrieval.','No original execution commit or independent manual identity-validation counts are established by current source hashes.','Distinct PID or cohort uniqueness does not validate person identity.']}
(OUT/'dblp_identity_audit.json').write_text(json.dumps(result,indent=2));pd.DataFrame(raw_checks).to_csv(OUT/'dblp_raw_xml_manifest.csv',index=False);pd.DataFrame(scopes).to_csv(OUT/'dblp_identity_counts.csv',index=False)
print(json.dumps(result,indent=2))
# Count author positions separately from distinct author--paper pairs.
focal=saved_a[saved_a.venue.isin(['ICML','NeurIPS']) & saved_a.year.between(2018,2024)]
repeated=focal[focal.duplicated(['paper_key','author_pid'],keep=False)]
index_table=pd.read_csv(GEO/'outputs/epj_distance_based_v10/private/epj_distance_full_index_papers_private.csv',keep_default_na=False)
duplicate_audit={'all_saved_extra_repeated_pid_rows':int(saved_a.duplicated(['paper_key','author_pid']).sum()),'focal_author_position_rows':len(focal),'focal_distinct_paper_pid_pairs':len(focal.drop_duplicates(['paper_key','author_pid'])),'focal_extra_repeated_pid_rows':int(focal.duplicated(['paper_key','author_pid']).sum()),'affected_paper_keys':sorted(repeated.paper_key.unique()),'affected_records_in_retained_index_papers':sorted(set(repeated.paper_key)&set(index_table.paper_key)),'models_refitted':False}
(OUT/'dblp_duplicate_pid_counts_recomputed.json').write_text(json.dumps(duplicate_audit,indent=2)+'\n')
