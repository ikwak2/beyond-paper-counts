#!/usr/bin/env python3
"""Offline verification of submission additions and current figure content.
Writes only under --output-dir; no model fits and no network access.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,importlib.util
import pandas as pd
import numpy as np

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir',type=Path,default=root/'outputs/verification')
    a=p.parse_args();out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    archive=root/'archive_v1.0.2'
    manifest=json.loads((archive/'provenance/release_manifest.json').read_text())
    bad=[name for name,want in manifest.items() if not (archive/name).exists() or sha(archive/name)!=want]
    assert not bad,bad
    report={'archive_files_verified':len(manifest),'models_refitted':False,'steps':[]}
    def run(label,args):
        result=subprocess.run([sys.executable,*map(str,args)],capture_output=True,text=True)
        (out/f'{label}.log').write_text(result.stdout+result.stderr)
        report['steps'].append({'name':label,'returncode':result.returncode})
        if result.returncode:raise RuntimeError(f'{label}: {result.stdout[-1000:]} {result.stderr[-1000:]}')
    run('author_checks',[root/'scripts/build_author_review_diagnostics.py','--archive-root',archive,'--output-dir',out/'author_checks'])
    checkfiles=sorted((root/'data/author_checks').glob('*.csv'))
    for f in checkfiles:assert f.read_bytes()==(out/'author_checks'/f.name).read_bytes(),f.name
    report['author_csvs_equal']=len(checkfiles)
    run('country_data',[root/'scripts/make_submission_country_data.py','--source-dir',archive/'results/additional_files','--output-dir',out/'country_comparison'])
    countryfiles=sorted((root/'data/country_comparison').glob('*.csv'))
    for f in countryfiles:assert f.read_bytes()==(out/'country_comparison'/f.name).read_bytes(),f.name
    report['country_csvs_equal']=len(countryfiles)
    # Original editing programs locate their assets relative to their own file.
    # Give them a disposable project so supplied final vector assets are preserved.
    sandbox=out/'figure_project';sandbox.mkdir(exist_ok=True)
    shutil.copytree(root/'scripts',sandbox/'scripts',dirs_exist_ok=True)
    shutil.copytree(root/'figures',sandbox/'figures',dirs_exist_ok=True)
    (sandbox/'data').mkdir(exist_ok=True)
    shutil.copy2(root/'data/table_s9_pri_specification_dashboard.csv',sandbox/'data/table_s9_pri_specification_dashboard.csv')
    for label,script in [('figures_1_3','rebuild_figures.py'),('figure_5','fix_rq3_labels.py'),('figure_s9','fix_s9_note.py')]:run(label,[sandbox/'scripts'/script])
    run('figures_2_4_from_csv',[root/'scripts/render_figures_2_4_from_csv.py',
        '--bundle-root',root,'--output-dir',sandbox/'figures'])
    run('figure_s1_reconstructed',[root/'scripts/revise_s1_axes.py','--output-dir',out/'reconstructed_s1'])
    original=pd.read_csv(root/'data/table_s9_pri_specification_dashboard.csv')
    drawn=pd.read_csv(out/'reconstructed_s1/figure_s1_plotted_values.csv')
    keys=['specification_family','spec_id','group'];joined=original.merge(drawn,on=keys,validate='one_to_one')
    assert len(joined)==176 and np.allclose(joined.change_2018_2024_x,joined.change_2018_2024_y,rtol=0,atol=1e-14)
    assert int(drawn.primary_marker.sum())==4
    assert drawn[drawn.primary_marker].specification_family.eq('existing_inspected_12spec').all()
    report['s1_frozen_values_verified']=176
    layout=json.loads((out/'reconstructed_s1/figure_s1_layout_validation.json').read_text())
    assert layout['status']=='PASS'
    assert layout['visible_endpoint_glyphs']==176 and layout['visible_primary_glyphs']==4
    assert layout['pdf_endpoint_vector_paths']==176 and layout['pdf_primary_star_vector_paths']==4
    assert not layout['text_overlap'] and not layout['pdf_footer_xlabel_overlap']
    assert layout['minimum_full_glyph_clearance_pixels_at_100dpi']>=2
    report['s1_layout_and_pdf_render_validation']=layout
    # Confirm the supplied renderer's transcribed Figure 3 values at printed precision.
    spec=importlib.util.spec_from_file_location('figures',root/'scripts/rebuild_figures.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    countries=pd.read_csv(root/'data/country_comparison/country_case_endpoints.csv').set_index('country')
    for name,c18,c24,s18,s24,p18,p24 in module.COUNTRY_ENDPOINTS:
        row=countries.loc[name]
        assert (c18,c24)==(row.accepted_credits_2018,row.accepted_credits_2024)
        assert (s18,s24)==(round(row.accepted_share_pct_2018,2),round(row.accepted_share_pct_2024,2))
        assert (p18,p24)==(round(row.PRI_2018,3),round(row.PRI_2024,3))
    report['figure3_country_rows_verified']=11
    crosswalk=pd.read_csv(root/'data/display_source_code_map.csv',keep_default_na=False)
    for _,row in crosswalk.iterrows():
        for col in ['data_paths','original_analysis_code','assembly_code','current_renderer','figure_paths']:
            for name in row[col].split('|'):
                if name:assert (root/name).is_file(),name
    report['crosswalk_rows_verified']=len(crosswalk)
    report['scope']='Frozen numerical inputs and script execution verified. Historical pipelines and full model fits are not rerun. Supplied final figure PDFs are not overwritten. S1 is a documented replacement renderer, not pixel-identical reproduction.'
    report['status']='PASS'
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
