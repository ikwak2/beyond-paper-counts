#!/usr/bin/env python3
"""Reconstructed renderer for S1 from all 176 frozen endpoint changes.
The supplied final PDF remains the submission asset. This new renderer verifies
and reproduces its scientific content, not its missing original drawing program.
"""
from pathlib import Path
import argparse
import json
import hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.transforms import Affine2D
import pandas as pd
import numpy as np

def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=root/'data/table_s9_pri_specification_dashboard.csv')
    p.add_argument('--output-dir',type=Path,default=root/'outputs/reconstructed_s1')
    a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    data=pd.read_csv(a.input,keep_default_na=False)
    assert len(data)==176 and not data.duplicated(['specification_family','spec_id','group']).any()
    families=[('existing_inspected_12spec',12,'A. Country-API-aggregate family'),('worklevel_32spec',32,'B. Work-level family')]
    groups=['China','Core Anglophone','Other non-core','India'];colors=['#12789A','#B87026','#397D79','#77678D']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(7.6,7.0),sharex=True)
    fig.subplots_adjust(left=.11,right=.98,bottom=.26,top=.9,wspace=.36)
    minimum=float(data.change_2018_2024.min());maximum=float(data.change_2018_2024.max())
    padding=max(.06, .06*(maximum-minimum))
    x_limits=(float(np.floor((minimum-padding)*20)/20),float(np.ceil((maximum+padding)*20)/20))
    marker_collections=[]
    plotted=[]
    primary='existing|conservative|top_full|ai_primary_peer_reviewed'
    for ax,(family,n,title) in zip(axes,families):
        subset=data[data.specification_family.eq(family)];specs=sorted(subset.spec_id.unique());assert len(specs)==n
        for j,g in enumerate(groups):
            rows=subset[subset.group.eq(g)].set_index('spec_id').loc[specs]
            y=np.arange(n)+j*.13-.195
            points=ax.scatter(rows.change_2018_2024,y,s=15,color=colors[j],zorder=3)
            marker_collections.append((ax,points,'point'))
            for k,(spec,row) in enumerate(rows.iterrows()):
                plotted.append({'specification_family':family,'local_specification_number':k+1,'spec_id':spec,'group':g,'change_2018_2024':row.change_2018_2024,'primary_marker':family==families[0][0] and spec==primary})
            if family==families[0][0]:
                k=specs.index(primary)
                star=ax.scatter([rows.loc[primary,'change_2018_2024']],[y[k]],marker='*',s=95,color=colors[j],edgecolor='black',linewidth=.4,zorder=4)
                marker_collections.append((ax,star,'primary'))
        ax.set_yticks(np.arange(n),[f'Spec {i+1}' for i in range(n)]);ax.set_ylim(n-.2,-.8)
        ax.axvline(0,color='#777777',lw=.7,ls='--');ax.grid(axis='x',color='#e3e3e3',lw=.5);ax.set_axisbelow(True)
        ax.set_xlim(*x_limits);ax.set_xlabel('PRI endpoint change, 2018 to 2024',labelpad=7)
        ax.set_title(f'{title}\n{n} specifications',fontsize=9)
    handles=[Line2D([],[],color=c,marker='o',linestyle='',label=('Other countries' if g=='Other non-core' else g)) for g,c in zip(groups,colors)]
    handles.append(Line2D([],[],color='black',marker='*',linestyle='',label='Primary specification',markersize=9))
    legend=fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.025),ncol=3,frameon=False)
    footer=fig.text(.5,.135,'Specification numbers are local to each family.',ha='center',fontsize=8)
    # Check complete glyph extents, including star tips and stroke widths.
    # Merely checking point centres would miss partially clipped primary stars.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    visible={'point':0,'primary':0};minimum_clearance=float('inf')
    for ax,collection,kind in marker_collections:
        boundary=ax.get_window_extent(renderer)
        path=collection.get_paths()[0]
        transforms=collection.get_transforms()
        centres=collection.get_offset_transform().transform(collection.get_offsets())
        stroke=max(collection.get_linewidths(),default=0)*fig.dpi/144
        for i,centre in enumerate(centres):
            glyph=path.get_extents(Affine2D(transforms[i % len(transforms)]))
            edges=(centre[0]+glyph.x0-stroke-boundary.x0,
                   boundary.x1-(centre[0]+glyph.x1+stroke),
                   centre[1]+glyph.y0-stroke-boundary.y0,
                   boundary.y1-(centre[1]+glyph.y1+stroke))
            clearance=min(edges);minimum_clearance=min(minimum_clearance,clearance)
            assert clearance>=2.0,(kind,centre,edges)
            visible[kind]+=1
    assert visible=={'point':176,'primary':4},visible
    footer_box=footer.get_window_extent(renderer)
    legend_box=legend.get_window_extent(renderer)
    label_boxes=[ax.xaxis.label.get_window_extent(renderer) for ax in axes]
    assert all(not footer_box.overlaps(box) and not legend_box.overlaps(box) for box in label_boxes)
    assert not footer_box.overlaps(legend_box)
    layout={'status':'PASS','data_minimum':minimum,'data_maximum':maximum,
            'x_limits':list(x_limits),'visible_endpoint_glyphs':visible['point'],
            'visible_primary_glyphs':visible['primary'],
            'minimum_full_glyph_clearance_pixels_at_100dpi':minimum_clearance,
            'footer_to_xlabel_gap_pixels':min(box.y0-footer_box.y1 for box in label_boxes),
            'legend_to_footer_gap_pixels':footer_box.y0-legend_box.y1,
            'text_overlap':False,
            'axes_pdf_rectangles':[[float(ax.bbox.x0*72/fig.dpi),float((fig.bbox.height-ax.bbox.y1)*72/fig.dpi),float(ax.bbox.x1*72/fig.dpi),float((fig.bbox.height-ax.bbox.y0)*72/fig.dpi)] for ax in axes]}
    fig.savefig(a.output_dir/'figure_s1_pri_specification_audit.pdf',metadata={'Title':'S1 content reproduction from frozen CSV','Creator':'reconstructed revise_s1_axes.py'})
    plt.close(fig)
    # Render the PDF itself, rather than relying only on Matplotlib's canvas.
    import fitz
    pdf_path=a.output_dir/'figure_s1_pri_specification_audit.pdf'
    with fitz.open(pdf_path) as document:
        assert len(document)==1
        page=document[0]
        boxes=[fitz.Rect(bounds) for bounds in layout['axes_pdf_rectangles']]
        point_paths=[];star_paths=[]
        for drawing in page.get_drawings():
            if drawing['type']!='fs' or not any(box.contains(drawing['rect']) for box in boxes):
                continue
            if len(drawing['items'])==8:point_paths.append(drawing)
            elif len(drawing['items'])==10:star_paths.append(drawing)
        assert len(point_paths)==176 and len(star_paths)==4,(len(point_paths),len(star_paths))
        layout['pdf_endpoint_vector_paths']=len(point_paths)
        layout['pdf_primary_star_vector_paths']=len(star_paths)
        footer_rects=page.search_for('Specification numbers are local to each family.')
        xlabel_rects=page.search_for('PRI endpoint change, 2018 to 2024')
        assert len(footer_rects)==1 and len(xlabel_rects)==2
        assert all(not footer_rects[0].intersects(label) for label in xlabel_rects)
        layout['pdf_footer_xlabel_overlap']=False
        pixmap=document[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
        png=a.output_dir/'figure_s1_rendered.png';pixmap.save(png)
        layout['pdf_pages']=len(document)
        layout['rendered_pixel_size']=[pixmap.width,pixmap.height]
    layout['pdf_sha256']=hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    layout['rendered_png_sha256']=hashlib.sha256(png.read_bytes()).hexdigest()
    (a.output_dir/'figure_s1_layout_validation.json').write_text(json.dumps(layout,indent=2)+'\n')
    pd.DataFrame(plotted).to_csv(a.output_dir/'figure_s1_plotted_values.csv',index=False,float_format='%.17g')
    print(json.dumps(layout,indent=2))
if __name__=='__main__':main()
