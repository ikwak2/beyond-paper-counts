#!/usr/bin/env python3
"""Export aggregate coverage from retained local source records, without person/paper IDs.
New audit utility prepared for this submission; it is not an archived original script.
No network access or model fitting. Original row-level inputs are not redistributed.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--country-input',required=True,type=Path)
    p.add_argument('--dblp-papers',required=True,type=Path)
    p.add_argument('--archive-root',type=Path,default=root/'archive_v1.0.2')
    p.add_argument('--output-dir',type=Path,default=root/'data/provenance')
    a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(a.country_input,keep_default_na=False)
    frame=frame[frame.venue.isin(['ICML','NeurIPS'])&frame.year.between(2018,2024)].copy()
    papers=pd.read_csv(a.dblp_papers,keep_default_na=False)
    papers=papers[papers.venue.isin(['ICML','NeurIPS'])&papers.year.between(2018,2024)]
    assert len(frame)==26872 and not frame.duplicated(['paper_id','venue','year']).any()
    assert set(zip(frame.paper_id,frame.venue,frame.year))==set(zip(papers.paper_key,papers.venue,papers.year))
    credits=[]
    for mapping,column,covered in [('conservative','primary_country_codes','primary_country_covered'),('sensitivity','sensitivity_country_codes','sensitivity_country_covered')]:
        for row in frame.to_dict('records'):
            cc=sorted(set(json.loads(row[column]))) if str(row[covered]).lower()=='true' else []
            for c in cc: credits.append({'year':row['year'],'country_mapping':mapping,'country_code':c,'full':1.0,'fractional':1/len(cc)})
    calculated=pd.DataFrame(credits).groupby(['year','country_mapping','country_code'],as_index=False)[['full','fractional']].sum()
    frozen_path=a.archive_root/'data/aggregate/accepted_country_credits.csv'
    frozen=pd.read_csv(frozen_path,keep_default_na=False)
    keys=['year','country_mapping','country_code']
    c=calculated.sort_values(keys).reset_index(drop=True);f=frozen.sort_values(keys).reset_index(drop=True)
    assert c[keys].equals(f[keys]);assert np.allclose(c[['full','fractional']],f[['full','fractional']],rtol=0,atol=1e-8)
    frame['countries']=frame.primary_country_codes.map(lambda x:sorted(set(json.loads(x))))
    frame['covered']=frame.primary_country_covered.astype(str).str.lower().eq('true') & frame.countries.map(bool)
    frame['credits']=frame.countries.map(len)
    out=frame.groupby(['venue','year'],as_index=False).agg(roster_papers=('paper_id','nunique'),country_resolved_papers=('covered','sum'),whole_country_credits=('credits','sum'))
    out['unresolved_papers']=out.roster_papers-out.country_resolved_papers
    out['coverage_percent']=100*out.country_resolved_papers/out.roster_papers
    out.to_csv(a.output_dir/'country_roster_coverage_by_venue_year.csv',index=False)
    info={'audit_kind':'new aggregate export from retained local source; no model refit','country_input_filename':a.country_input.name,'country_input_sha256':sha(a.country_input),'dblp_roster_filename':a.dblp_papers.name,'dblp_roster_sha256':sha(a.dblp_papers),'frozen_country_credits_sha256':sha(frozen_path),'roster_keys_equal':True,'frozen_credit_rows_compared':len(c),'all_frozen_credit_values_equal_tolerance_1e-8':True,'output_sha256':sha(a.output_dir/'country_roster_coverage_by_venue_year.csv'),'limitations':'Row-level source file is retained locally and is not redistributed. Equality of derived aggregates and roster keys validates these coverage counts; it does not establish identity correctness or prove an original collection date.'}
    (a.output_dir/'country_coverage_recovery.json').write_text(json.dumps(info,indent=2)+'\n')
    print(out.to_string(index=False));print(json.dumps(info,indent=2))
if __name__=='__main__':main()
