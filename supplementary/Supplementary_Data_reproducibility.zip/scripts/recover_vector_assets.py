"""Recover unchanged vector figure forms from the two supplied manuscript PDFs.

This copies the published figure objects; it does not digitize points or refit models.
Usage: python recover_vector_assets.py MAIN_PDF SUPPLEMENT_PDF OUTPUT_DIRECTORY
"""
from pathlib import Path
import argparse
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, NameObject, RectangleObject


def recover(source, page_number, object_name, destination):
    reader = PdfReader(str(source))
    writer = PdfWriter()
    page = writer.add_page(reader.pages[page_number - 1])
    obj = page['/Resources']['/XObject'][object_name].get_object()
    bounds = [float(x) for x in obj['/BBox']]
    x0, y0, x1, y1 = bounds
    stream = DecodedStreamObject()
    stream.set_data(f'q 1 0 0 1 {-x0} {-y0} cm {object_name} Do Q\n'.encode('ascii'))
    page[NameObject('/Contents')] = writer._add_object(stream)
    page.mediabox = RectangleObject([0, 0, x1 - x0, y1 - y0])
    page.cropbox = RectangleObject([0, 0, x1 - x0, y1 - y0])
    for key in ['/Annots', '/Rotate', '/TrimBox', '/ArtBox', '/BleedBox']:
        page.pop(NameObject(key), None)
    writer.add_metadata({'/Title': destination.stem, '/Subject': 'Vector figure recovered without numerical alteration from the supplied PDF'})
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('wb') as f:
        writer.write(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('main_pdf', type=Path)
    parser.add_argument('supplement_pdf', type=Path)
    parser.add_argument('output_directory', type=Path)
    args = parser.parse_args()
    main_figs = [(3, '/Im1', 'Figure_1_original.pdf'),
                 (4, '/Im2', 'Figure_2_original.pdf'),
                 (6, '/Im3', 'Figure_3_original.pdf'),
                 (8, '/Im4', 'Figure_5_original.pdf')]
    supplement_figs = [
        (3, '/Im1', 'figure_s1_pri_specification_audit_original.pdf'),
        (4, '/Im2', 'figure_s2_denominator_missingness_bounds.pdf'),
        (5, '/Im3', 'figure_s3_primary_four_group_trajectories.pdf'),
        (6, '/Im4', 'figure_s4_external_production_triangulation.pdf'),
        (8, '/Im5', 'figure_s5_calibration_margin.pdf'),
        (9, '/Im6', 'figure_s6_country_group_distance.pdf'),
        (10, '/Im7', 'figure_s7_diagnostic_distance_coauthor.pdf'),
        (11, '/Im8', 'figure_s8_within_two_sensitivity.pdf'),
        (22, '/Im9', 'figure_s9_country_annual_trajectories.pdf'),
        (23, '/Im10', 'Figure_4.pdf')]
    for source, items in [(args.main_pdf, main_figs), (args.supplement_pdf, supplement_figs)]:
        for page, obj, filename in items:
            target = args.output_directory / filename
            recover(source, page, obj, target)
            print(target.name)


if __name__ == '__main__':
    main()
