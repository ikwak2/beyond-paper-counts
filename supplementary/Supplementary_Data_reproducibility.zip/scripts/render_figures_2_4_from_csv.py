#!/usr/bin/env python3
"""Render current Figures 2 and 4 solely from frozen CSVs.

No manuscript page is imported. No models, bootstrap samples, estimates or
intervals are recomputed. The layout follows the reviewed figures; every
plotted numerical array is checked against its source at atol=1e-9, rtol=0.
"""
from pathlib import Path
import argparse,collections,csv,hashlib,json,re,tempfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
import fitz
from pdfminer.high_level import extract_text

TOL=1e-9
FORBIDDEN=['Additional file','Panels A and B','Gray bars','Table S3','monotonic','1289','1519','Endpoint change']
INPUTS={
 'fig2a':'archive_v1.0.2/results/figure_data/figure_2_panelA_aggregate_data.csv',
 'fig2b':'archive_v1.0.2/results/figure_data/figure_2_panelB_four_group_data.csv',
 'fig2c':'archive_v1.0.2/results/additional_files/table_s10_denominator_missingness_bounds.csv',
 'fig4a':'archive_v1.0.2/data/figure_inputs/figure3_calibration_coordinates.csv',
 'fig4b':'archive_v1.0.2/results/tables/table_3_annual_distance.csv',
 'calibration_labels':'archive_v1.0.2/results/additional_files/table_s2_distance_calibration_gates.csv',
}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return list(csv.DictReader(Path(path).open(encoding='utf-8-sig',newline='')))
def values(rows,key):return np.array([float(row[key]) for row in rows])
def normalized(text):return ''.join(text.split()).replace('−','-')

class Checks:
 def __init__(self,name):self.name=name;self.records=[]
 def array(self,label,source,plotted,source_file,fields):
  a=np.asarray(source,dtype=float);b=np.asarray(plotted,dtype=float)
  assert a.shape==b.shape,(label,a.shape,b.shape)
  error=float(np.max(np.abs(a-b))) if a.size else 0.0
  if not np.isfinite(a).all() or not np.isfinite(b).all() or error>TOL:
   raise ValueError(f'NUMERICAL MISMATCH: {self.name} {label}: {error} > {TOL}')
  self.records.append({'label':label,'source_file':source_file,'source_fields':fields,
                       'source_values':a.tolist(),'plotted_values':b.tolist(),
                       'count':int(a.size),'max_abs_error':error,'match':True})
 def band(self,label,x,lo,hi,artist,source_file,fields):
  expected=np.r_[np.c_[x,lo],np.c_[x,hi]]
  vertices=np.concatenate([p.vertices for p in artist.get_paths()])
  forward=np.min(np.max(np.abs(expected[:,None,:]-vertices[None,:,:]),axis=2),axis=1)
  reverse=np.min(np.max(np.abs(vertices[:,None,:]-expected[None,:,:]),axis=2),axis=1)
  assert max(float(forward.max()),float(reverse.max()))<=TOL,label
  self.array(label,expected,vertices[np.argmin(np.max(np.abs(expected[:,None,:]-vertices[None,:,:]),axis=2),axis=1)],source_file,fields)


def axis(fig,width,height,bounds):
 left,top,right,bottom=bounds
 return fig.add_axes([left/width,(height-bottom)/height,(right-left)/width,(bottom-top)/height])

def finish(fig,name,out,checks,meta):
 fig.canvas.draw();renderer=fig.canvas.get_renderer()
 labels=[]
 for text in fig.findobj(Text):
  if text.get_visible() and text.get_text():
   labels.append(text.get_text());box=text.get_window_extent(renderer)
   assert fig.bbox.contains(box.x0,box.y0) and fig.bbox.contains(box.x1,box.y1),(name,text.get_text(),box.bounds)
   assert text.get_fontfamily()==['DejaVu Sans']
 expected=collections.Counter(normalized(''.join(labels)))
 target=out/name
 with tempfile.TemporaryDirectory(prefix='native-figure-') as directory:
  unsubset=Path(directory)/name
  fig.savefig(unsubset,facecolor='white',metadata={'Title':name.replace('_',' '),'Creator':'Frozen CSV native vector renderer'})
  with fitz.open(unsubset) as doc:
   pre=doc[0].get_pixmap(dpi=200,alpha=False)
   doc.subset_fonts()
   doc.save(target,garbage=4,deflate=True)
  with fitz.open(target) as doc:
   post=doc[0].get_pixmap(dpi=200,alpha=False)
   assert pre.samples==post.samples,(name,'font subsetting changed rendered pixels')
   forms=[]
   for xref in range(1,doc.xref_length()):
    if doc.xref_get_key(xref,'Subtype')!=('name','/Form'):continue
    code=doc.xref_stream(xref) or b''
    bbox=doc.xref_get_key(xref,'BBox')[1]
    numbers=[float(x) for x in re.findall(r'[-+]?\d*\.?\d+',bbox)]
    width=abs(numbers[2]-numbers[0]);height=abs(numbers[3]-numbers[1])
    has_text=bool(re.search(rb'\bBT\b|\bTj\b|\bTJ\b',code));nested=bool(re.search(rb'\bDo\b',code))
    # Matplotlib reuses tiny native marker paths as Form XObjects. They are
    # permitted; imported/cropped document pages and text-bearing forms are not.
    assert width<24 and height<24 and not has_text and not nested,(name,xref,bbox)
    forms.append({'xref':xref,'bbox':numbers,'kind':'native marker path','text_operators':False,'nested_xobject':False})
   assert all(f[2]!='Type3' for f in doc[0].get_fonts())
   page_size=list(doc[0].rect)
 text=extract_text(target)
 counts={p:text.count(p) for p in FORBIDDEN}
 compact=' '.join(text.split());normalized_counts={p:compact.count(p) for p in FORBIDDEN}
 assert not any(counts.values()) and not any(normalized_counts.values()),(name,counts,normalized_counts)
 actual=collections.Counter(normalized(text))
 assert actual==expected,(name,'extracted text differs from visible labels',actual-expected,expected-actual)
 fig.savefig(out/(target.stem+'.png'),dpi=200,facecolor='white')
 plt.close(fig)
 result={'status':'PASS','figure':name,'atol':TOL,'rtol':0,'all_plotted_values_match_csv':True,
         'checked_numeric_values':sum(r['count'] for r in checks.records),
         'maximum_absolute_error':max(r['max_abs_error'] for r in checks.records),
         'checks':checks.records,'visible_labels':labels,'pdfminer_text':text,
         'pdfminer_only_visible_label_characters':True,'forbidden_raw_counts':counts,
         'forbidden_whitespace_normalized_counts':normalized_counts,
         'form_xobjects':forms,'cropped_or_imported_page_forms':0,
         'font_family':'DejaVu Sans','fonts_subset_before_final_save':True,
         'font_subset_200dpi_pixel_difference':0,'page_size_pt':page_size,
         'output_sha256':sha(target),'layout_and_display_notes':meta}
 (out/(target.stem+'_csv_validation.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return result


def figure2(root,out,data):
 width,height=475.20001220703125,507.1428527832031
 factor=1.252023374
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8*factor,'axes.titlesize':8.5*factor,
                      'axes.labelsize':8*factor,'xtick.labelsize':7.5*factor,'ytick.labelsize':7.5*factor,
                      'legend.fontsize':7.5*factor,'axes.linewidth':.8*factor,
                      'xtick.major.size':3.5*factor,'ytick.major.size':3.5*factor,
                      'xtick.major.pad':3.5*factor,'ytick.major.pad':3.5*factor,
                      'axes.labelpad':4*factor,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
 fig=plt.figure(figsize=(width/72,height/72))
 a=axis(fig,width,height,[72.093399,34.716919,248.319870,171.017181])
 b=axis(fig,width,height,[276.516113,34.716919,452.742584,171.017181])
 c=axis(fig,width,height,[118.800003,331.066833,458.567993,446.842865])
 check=Checks('Figure 2');colors={'Core Anglophone':'#D55E00','All other countries':'#3F6E8C','China':'#0072B2','India':'#009E73','Other countries':'#CC79A7'}
 markers={'Core Anglophone':'s','All other countries':'o','China':'o','India':'^','Other countries':'D'}
 styles={'Core Anglophone':'--','All other countries':'-','China':'-','India':'-.','Other countries':':'}
 for ax,key,labels,linewidth,size in [(a,'fig2a',['Core Anglophone','All other countries'],1.5,3.6),(b,'fig2b',['Core Anglophone','China','India','Other countries'],1.4,3.4)]:
  for label in labels:
   records=sorted([r for r in data[key] if r['display_group']==label],key=lambda r:int(r['year']))
   assert len(records)==7
   x=values(records,'year');y=values(records,'pri')
   line,=ax.plot(x,y,label=label,color=colors[label],marker=markers[label],ls=styles[label],
                lw=linewidth*factor,markersize=size*factor,markeredgewidth=.5*factor,zorder=3)
   check.array(key+' '+label+' years',x,line.get_xdata(),INPUTS[key],['year'])
   check.array(key+' '+label+' PRI',y,line.get_ydata(),INPUTS[key],['pri'])
  ax.axhline(1,color='#626b73',lw=.9*factor,ls=(0,(4,3)),zorder=1)
  ax.set(ylim=(0,3),xlim=(2017.6,2024.4),xlabel='Publication year')
  ax.set_xticks(range(2018,2025),[str(y)[2:] if y%2 else str(y) for y in range(2018,2025)])
  ax.set_yticks(np.arange(0,3.1,.5));ax.grid(axis='y',color='#dce2e7',lw=.6*factor,zorder=0)
 a.set_ylabel('Production-adjusted\nrepresentation index (PRI)')
 a.set_title('a  Core Anglophone vs\n    all other countries',loc='left',weight='bold',pad=5*factor)
 b.set_title('b  All other countries\n    decomposed',loc='left',weight='bold',pad=5*factor)
 b.tick_params(labelleft=False)
 a.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.20),handlelength=2.2,handletextpad=.5)
 b.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.20),handlelength=2.2,handletextpad=.5,labelspacing=.3)
 # Bottom panel retains its own reviewed 8.3-point scale.
 c.tick_params(axis='both',labelsize=8.3,length=3.5,pad=3.5)
 for spine in c.spines.values():spine.set_linewidth(.8)
 order=['Core Anglophone','China','India','Other countries'];y=np.arange(4)[::-1]
 for counting,offset,color,marker,label in [('full',.14,'#0c607e','s','Whole-count numerator'),('fractional',-.14,'#c26a2a','o','Fractional-count numerator')]:
  records=[]
  for label_group in order:
   found=[r for r in data['fig2c'] if r['numerator_counting']==counting and r['group'] in {label_group,'Other non-core' if label_group=='Other countries' else label_group}]
   assert len(found)==1;records+=found
  lo=values(records,'assumption_free_change_low');hi=values(records,'assumption_free_change_high');est=values(records,'observed_endpoint_change')
  intervals=c.hlines(y+offset,lo,hi,color=color,lw=2.1)
  points=c.scatter(est,y+offset,color=color,marker=marker,s=18,label=label,zorder=3)
  check.array('fig2c '+counting+' estimates',est,np.asarray(points.get_offsets())[:,0],INPUTS['fig2c'],['observed_endpoint_change'])
  segments=intervals.get_segments()
  check.array('fig2c '+counting+' lower',lo,[v[0,0] for v in segments],INPUTS['fig2c'],['assumption_free_change_low'])
  check.array('fig2c '+counting+' upper',hi,[v[1,0] for v in segments],INPUTS['fig2c'],['assumption_free_change_high'])
 c.axvline(0,color='#777777',ls='--',lw=.8,zorder=0)
 c.set(ylim=(-.5,3.5),xlim=(-3.55,2.15));c.set_yticks(y,order);c.set_xticks([-3,-2,-1,0,1,2])
 c.grid(axis='x',color='#e6ebef',lw=.7);c.set_axisbelow(True)
 c.set_xlabel('2024 minus 2018 PRI change',fontsize=8.3,labelpad=6)
 c.legend(loc='lower center',bbox_to_anchor=(.5,-.5),ncol=2,frameon=False,fontsize=7.8,handletextpad=.4,columnspacing=1.1)
 fig.text(.03,1-280.414856/height,'c  Country-missingness bounds under a separate denominator',fontsize=9.1,weight='bold')
 fig.text(.03,1-299.710846/height,'Strict first-position fractional denominator; points show its observed change.',fontsize=7.7,color='#454545')
 return finish(fig,'Figure_2_revised.pdf',out,check,{'panels':'a pooled PRI; b four-group PRI; c separate missingness bounds',
     'panel_a_xlim':list(a.get_xlim()),'panel_b_xlim':list(b.get_xlim()),'panel_ab_ylim':[0,3],
     'panel_c_xlim':list(c.get_xlim()),'panel_c_ylim':list(c.get_ylim()),
     'current_frozen_panel_A_used_directly':'No pooling or ratio recomputation.',
     'native_marker_forms_are_not_document_pages':True})


def figure4(root,out,data):
 width,height=376.0,278.0;factor=.99593006
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8*factor,'axes.titlesize':8.5*factor,
                      'axes.labelsize':8*factor,'xtick.labelsize':7.5*factor,'ytick.labelsize':7.5*factor,
                      'legend.fontsize':7.5*factor,'axes.linewidth':.8*factor,
                      'xtick.major.size':3.5*factor,'ytick.major.size':3.5*factor,
                      'xtick.major.pad':3.5*factor,'ytick.major.pad':3.5*factor,
                      'axes.labelpad':4*factor,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
 fig=plt.figure(figsize=(width/72,height/72))
 a=axis(fig,width,height,[61.151367,28.312546,173.817352,177.104492])
 b=axis(fig,width,height,[237.191956,28.312546,356.899536,177.104492])
 check=Checks('Figure 4');pilot=data['fig4a'];assert len(pilot)==249 and all(r['distance_observed']=='True' for r in pilot)
 for flag,color,label,alpha in [('False','#B8B0AD','Own not closer (26.5%)',.62),('True','#4C78A8','Own closer (73.5%)',.68)]:
  records=[r for r in pilot if r['own_portfolio_closer_than_permuted_median']==flag]
  x=values(records,'specter2_title_portfolio_distance');y=values(records,'permuted_other_portfolio_median_distance')
  artist=a.scatter(x,y,s=8*factor**2,alpha=alpha,color=color,edgecolor='none',label=label)
  check.array('fig4a '+flag+' scatter coordinates',np.c_[x,y],np.asarray(artist.get_offsets()),INPUTS['fig4a'],['specter2_title_portfolio_distance','permuted_other_portfolio_median_distance'])
 xall=values(pilot,'specter2_title_portfolio_distance');yall=values(pilot,'permuted_other_portfolio_median_distance')
 limits=[float(min(xall.min(),yall.min())-.008),float(max(xall.max(),yall.max())+.008)]
 a.plot(limits,limits,'--',color='#455A64',lw=.8*factor)
 a.set(xlim=limits,ylim=limits,xlabel='Own prior-portfolio\ndistance',ylabel='Median randomized distance')
 a.set_xticks([0,.1,.2]);a.set_yticks([0,.05,.10,.15,.20])
 a.set_title('a  Random-portfolio\n    calibration',loc='left',weight='bold',pad=6*factor)
 gates={r['metric']:float(r['value']) for r in data['calibration_labels']}
 annotation=f"Median margin\n= {gates['paired median margin']:.3f}"
 assert annotation=='Median margin\n= 0.026'
 assert f"{100*gates['own portfolio closer share']:.1f}"=='73.5'
 assert f"{100*(1-gates['own portfolio closer share']):.1f}"=='26.5'
 a.text(.02,.97,annotation,transform=a.transAxes,ha='left',va='top',fontsize=7.5*factor)
 a.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.33),fontsize=7.5*factor,handlelength=1,handletextpad=.25)
 annual=sorted(data['fig4b'],key=lambda r:int(r['index_year']));assert len(annual)==7
 x=values(annual,'index_year');median=values(annual,'median_distance');mlo=values(annual,'median_ci_low');mhi=values(annual,'median_ci_high')
 qlo=values(annual,'q25_distance');qhi=values(annual,'q75_distance');mean=values(annual,'adjusted_mean_distance');alo=values(annual,'ci_low');ahi=values(annual,'ci_high')
 qband=b.fill_between(x,qlo,qhi,color='#4C78A8',alpha=.11,label='Q25–Q75 band')
 obs=b.errorbar(x,median,yerr=[median-mlo,mhi-median],fmt='o-',color='#4C78A8',lw=1.2*factor,capsize=2*factor,markersize=3*factor,label='Observed median\n(95% interval)')
 adj,=b.plot(x,mean,'s-',color='#E15759',lw=1.2*factor,markersize=3*factor,label='Adjusted mean')
 aband=b.fill_between(x,alo,ahi,color='#E15759',alpha=.12)
 check.array('fig4b years',x,obs.lines[0].get_xdata(),INPUTS['fig4b'],['index_year'])
 check.array('fig4b medians',median,obs.lines[0].get_ydata(),INPUTS['fig4b'],['median_distance'])
 msegs=obs.lines[2][0].get_segments()
 check.array('fig4b median lower CI',mlo,[v[0,1] for v in msegs],INPUTS['fig4b'],['median_ci_low'])
 check.array('fig4b median upper CI',mhi,[v[1,1] for v in msegs],INPUTS['fig4b'],['median_ci_high'])
 check.array('fig4b adjusted means',mean,adj.get_ydata(),INPUTS['fig4b'],['adjusted_mean_distance'])
 check.band('fig4b quartiles',x,qlo,qhi,qband,INPUTS['fig4b'],['index_year','q25_distance','q75_distance'])
 check.band('fig4b adjusted-mean CI',x,alo,ahi,aband,INPUTS['fig4b'],['index_year','ci_low','ci_high'])
 # Same autoscale margins as the reviewed plot, stated explicitly for stability.
 span=float(qhi.max()-qlo.min());ylim=(float(qlo.min()-.05*span),float(qhi.max()+.05*span))
 b.set(xlim=(2017.7,2024.3),ylim=ylim,xlabel='Entry year',ylabel='Title-portfolio distance')
 b.set_xticks([2018,2020,2022,2024]);b.set_yticks([.07,.08,.09,.10,.11,.12])
 b.set_title('b  Prior-to-entry\n    distance by year',loc='left',weight='bold',pad=6*factor)
 b.legend(handles=[qband,adj,obs],frameon=False,loc='upper center',bbox_to_anchor=(.5,-.25),fontsize=7.5*factor,handlelength=1.3,handletextpad=.3)
 return finish(fig,'Figure_4.pdf',out,check,{'pilot_points':249,'annual_rows':7,
   'panel_a_xlim':limits,'panel_a_ylim':limits,'panel_b_xlim':list(b.get_xlim()),'panel_b_ylim':list(b.get_ylim()),
   'rounded_visible_annotation':{'source_value':gates['paired median margin'],'display':'0.026','rule':'Existing three-decimal display; no point estimate recalculated.'},
   'legend_percentages':'Existing one-decimal display of the frozen calibration gate.'})


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--bundle-root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--output-dir',type=Path);args=parser.parse_args()
 root=args.bundle_root.resolve();out=args.output_dir or root/'figures';out.mkdir(parents=True,exist_ok=True)
 crosswalk=(root/'data/display_source_code_map.csv').read_text();data={}
 for name,relative in INPUTS.items():
  path=root/relative
  if not path.is_file():raise FileNotFoundError('Required frozen input missing: '+str(path))
  if name!='calibration_labels' and relative not in crosswalk:raise ValueError('Input source not identified by display crosswalk: '+relative)
  data[name]=read(path)
 assert len(data['fig2a'])==14 and len(data['fig2b'])==28 and len(data['fig2c'])==8
 reports=[figure2(root,out,data),figure4(root,out,data)]
 result={'status':'PASS','scope':'Frozen CSV rendering only; no model fits, bootstrap, re-estimation or collection.',
         'inputs':{relative:sha(root/relative) for relative in INPUTS.values()},
         'crosswalk_sha256':sha(root/'data/display_source_code_map.csv'),
         'checked_numeric_values':sum(r['checked_numeric_values'] for r in reports),
         'maximum_absolute_error':max(r['maximum_absolute_error'] for r in reports),
         'atol':TOL,'figures':[{'file':r['figure'],'validation':Path(r['figure']).stem+'_csv_validation.json','sha256':r['output_sha256']} for r in reports]}
 (out/'figures_2_4_csv_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
