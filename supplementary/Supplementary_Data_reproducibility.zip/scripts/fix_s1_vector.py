#!/usr/bin/env python3
"""Correct Figure S1 labels without changing its plotted data or coordinates.

Run from VS Code's terminal:
    python scripts/fix_s1_vector.py

Dependency: PyMuPDF (``pip install pymupdf``).

The input is the exact vector figure recovered from the supplied supplementary
PDF.  The script edits its existing PDF drawing stream.  It does not digitize
scatter positions, infer numerical values, or fit a statistical model.

Changes are deliberately limited to:
* suppressing the four outline stars in panel B (the colored markers under
  them are preserved), because the primary specification belongs to panel A;
* making the panel and legend labels agree with the manuscript;
* removing the topic-linkage-gate annotation, which is explained in Methods.

The shared vertical scale and panel A's unused rows are retained to avoid
introducing a geometric reinterpretation of the original data display.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re

import fitz


B_STAR_PATTERN = re.compile(
    r"(Q q 412\.94875 59\.56375 354\.39 243\.798125 re W n "
    r"/A4 gs 1 j 1\.2 w\s+0\.0666666667 G /DeviceRGB cs\s+)"
    r"(.*?)"
    r"(\n\nS)",
    re.DOTALL,
)


def form_stream(doc: fitz.Document) -> tuple[int, str]:
    """Find the source figure's form; reject an unexpected document layout."""
    candidates = []
    for xref, *_ in doc[0].get_xobjects():
        data = doc.xref_stream(xref)
        if data and b"/M0 Do" in data and b"412.94875 59.56375 354.39 243.798125" in data:
            candidates.append((xref, data.decode("latin-1")))
    if len(candidates) != 1:
        raise ValueError(f"Expected one original Figure S1 drawing stream, found {len(candidates)}")
    return candidates[0]


def replace_text_at(
    stream: str, x: str, y: str, new_text: str, font_size: int
) -> str:
    """Replace one original PDF text block at a verified baseline coordinate."""
    pattern = re.compile(
        r"(q\s+1 0 -0 1 " + re.escape(x) + r" " + re.escape(y)
        + r" cm\s+BT\s+)(.*?)(ET\s+Q)", re.DOTALL
    )
    if len(pattern.findall(stream)) != 1:
        raise ValueError(f"Expected exactly one text block at ({x}, {y})")
    # These labels use ASCII characters already present in the original F2
    # font.  Keep the original embedded font, baseline, and text size.
    escaped = new_text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    body = f"/F2 {font_size} Tf\n0 0 Td\n({escaped}) Tj\n" if new_text else ""
    return pattern.sub(lambda m: m.group(1) + body + m.group(3), stream)


def data_marker_signatures(page: fitz.Page) -> list[tuple]:
    """Capture all 176 original colored markers inside the two plot areas."""
    plot_colors = {
        (0.0, 0.447059, 0.698039),
        (0.835294, 0.368627, 0.0),
        (0.8, 0.47451, 0.654902),
        (0.0, 0.619608, 0.45098),
    }
    found = []
    for drawing in page.get_drawings():
        fill = drawing.get("fill")
        if fill is None or tuple(round(v, 6) for v in fill) not in plot_colors:
            continue
        rect = drawing["rect"]
        cx, cy = (rect.x0 + rect.x1) / 2, (rect.y0 + rect.y1) / 2
        if not (46 < cx < 768 and 62 < cy < 306):
            continue
        found.append(
            (
                drawing["type"],
                tuple(round(v, 6) for v in fill),
                tuple(round(v, 5) for v in rect),
                repr(drawing["items"]),
            )
        )
    return found


def star_counts(page: fitz.Page) -> tuple[int, int, int]:
    left = right = legend = 0
    for drawing in page.get_drawings():
        color = drawing.get("color")
        if color is None or max(abs(v - 0.06666667) for v in color) > 1e-4:
            continue
        if len(drawing["items"]) < 9 or drawing.get("fill") is not None:
            continue
        r = drawing["rect"]
        cx, cy = (r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2
        if cy < 30:
            legend += 1
        elif cx < 405:
            left += 1
        else:
            right += 1
    return left, right, legend


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=project / "figures/figure_s1_pri_specification_audit_original.pdf")
    parser.add_argument("--output", type=Path, default=project / "figures/figure_s1_pri_specification_audit.pdf")
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        raise ValueError("Keep the recovered original PDF separate from the revised output")

    with fitz.open(args.input) as doc:
        if len(doc) != 1:
            raise ValueError("Expected a one-page vector figure")
        before_markers = data_marker_signatures(doc[0])
        if len(before_markers) != 176:
            raise ValueError(f"Expected 176 original colored data markers, found {len(before_markers)}")
        if star_counts(doc[0]) != (4, 4, 1):
            raise ValueError(f"Unexpected original star layout: {star_counts(doc[0])}")

        xref, stream = form_stream(doc)
        original_marker_placements = re.findall(r"1 0 0 1 [^\n]+ cm /M[0-7] Do", stream)
        matches = list(B_STAR_PATTERN.finditer(stream))
        if len(matches) != 4:
            raise ValueError(f"Expected four panel-B stars, found {len(matches)}")

        # PDF's n operator ends a path without painting it.  This preserves all
        # graphics-state changes and all underlying colored data points.
        stream = B_STAR_PATTERN.sub(lambda m: m.group(1) + m.group(2) + "\n\nn", stream)
        stream = replace_text_at(stream, "46.41875", "309.361875", "A. Country-API-aggregate family", 9)
        stream = replace_text_at(stream, "412.94875", "309.361875", "B. Work-level family", 9)
        stream = replace_text_at(stream, "365.4209375", "354.003515625", "Other countries", 7)
        stream = replace_text_at(stream, "189.006875", "9.121875", "", 8)

        if re.findall(r"1 0 0 1 [^\n]+ cm /M[0-7] Do", stream) != original_marker_placements:
            raise ValueError("A colored-marker placement was changed")
        doc.update_stream(xref, stream.encode("latin-1"))
        if data_marker_signatures(doc[0]) != before_markers:
            raise ValueError("The original colored data-marker geometry was changed")
        if star_counts(doc[0]) != (4, 0, 1):
            raise ValueError(f"Unexpected revised star layout: {star_counts(doc[0])}")

        text = doc[0].get_text()
        for label in ("A. Country-API-aggregate family", "B. Work-level family", "Other countries"):
            if label not in text:
                raise ValueError(f"New label did not render as expected: {label}")
        if "80% linkage gate" in text or "Other non-core" in text:
            raise ValueError("A superseded label remains")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        doc.save(args.output, garbage=4, deflate=True)

    # Reopen the final bytes to check that vector paths survived serialization.
    with fitz.open(args.output) as saved:
        if data_marker_signatures(saved[0]) != before_markers or star_counts(saved[0]) != (4, 0, 1):
            raise ValueError("Final PDF verification failed")
        saved[0].get_pixmap(matrix=fitz.Matrix(2, 2)).save(args.output.with_suffix(".png"))
    print("Preserved all 176 colored data markers and their exact vector geometry.")
    print("Primary stars: panel A 4 retained; panel B 4 removed; legend 1 retained.")
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
