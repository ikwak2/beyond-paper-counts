#!/usr/bin/env python3
"""Remove only the overlapping bottom annotation in Supplementary Figure S9.

Run from any directory: python scripts/fix_s9_note.py
Dependency: PyMuPDF.

The original recovered vector PDF is preserved as
figures/figure_s9_country_annual_trajectories_original.pdf on the first run.
Subsequent runs always read that original. The annotation is already stated
in the supplementary caption. Its one BT...ET block is emptied in the
original Form XObject; no redaction, rasterization, white overlay, numerical
reconstruction, or other layout change is performed.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil

import fitz


NOTE = "All y-axes start at zero; maxima vary by country."
# Native, unmodified Matplotlib Form XObject baseline for this annotation.
NOTE_X = "222.5550433952"
NOTE_Y = "9.60234375"


def drawing_geometry(page: fitz.Page) -> list[tuple]:
    """Capture the original paths, their coordinates, and graphical styles."""
    return [
        (
            drawing["type"],
            tuple(drawing["rect"]),
            repr(drawing["items"]),
            drawing.get("color"),
            drawing.get("fill"),
            drawing.get("width"),
            drawing.get("dashes"),
            drawing.get("lineCap"),
            drawing.get("lineJoin"),
            drawing.get("fill_opacity"),
            drawing.get("stroke_opacity"),
        )
        for drawing in page.get_drawings()
    ]


def text_spans(page: fitz.Page) -> list[tuple]:
    """Preserve exact text, font properties, bounding boxes, and baselines."""
    return [
        (
            span["text"],
            tuple(span["bbox"]),
            tuple(span["origin"]),
            span["font"],
            span["size"],
            span["color"],
        )
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        for span in line.get("spans", [])
    ]


def remove_note(doc: fitz.Document) -> None:
    pattern = re.compile(
        r"(q\s+1 0 -0 1 "
        + re.escape(NOTE_X)
        + r" "
        + re.escape(NOTE_Y)
        + r" cm\s+)BT(.*?)ET(\s+Q)",
        re.DOTALL,
    )
    matches = []
    for xref, *_ in doc[0].get_xobjects():
        raw = doc.xref_stream(xref)
        if raw is None:
            continue
        stream = raw.decode("latin-1")
        if pattern.search(stream):
            matches.append((xref, stream))
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one annotation Form; found {len(matches)}")
    xref, original = matches[0]
    if len(pattern.findall(original)) != 1:
        raise RuntimeError("Annotation baseline is not unique")
    revised = pattern.sub(lambda m: m.group(1) + "BT\nET" + m.group(3), original)
    # Every operator outside the original text bodies must remain identical.
    strip_text = lambda s: re.sub(r"BT.*?ET", "", s, flags=re.DOTALL)
    if strip_text(revised) != strip_text(original):
        raise RuntimeError("Unexpected non-text stream modification")
    doc.update_stream(xref, revised.encode("latin-1"))


def check_page(page, expected_geometry, expected_text, expected_rect):
    if tuple(page.rect) != expected_rect:
        raise RuntimeError("Page size changed")
    if drawing_geometry(page) != expected_geometry:
        raise RuntimeError("Original vector drawing geometry/style changed")
    if text_spans(page) != expected_text:
        raise RuntimeError("A text span other than the requested note changed")
    if NOTE in page.get_text():
        raise RuntimeError("The note remains in text extraction")


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    figures = project / "figures"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input", type=Path,
        default=figures / "figure_s9_country_annual_trajectories_original.pdf",
    )
    parser.add_argument(
        "--output", type=Path,
        default=figures / "figure_s9_country_annual_trajectories.pdf",
    )
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        raise RuntimeError("The input must be preserved separately from the output")
    if not args.input.exists():
        if not args.output.exists():
            raise FileNotFoundError("No recovered original S9 PDF is available")
        # Confirm the current recovered figure is the unrevised source before backup.
        with fitz.open(args.output) as recovered:
            if len(recovered) != 1 or recovered[0].get_text().count(NOTE) != 1:
                raise RuntimeError("Current output is not the original figure with its note")
        shutil.copy2(args.output, args.input)

    with fitz.open(args.input) as doc:
        if len(doc) != 1:
            raise RuntimeError("Expected one standalone figure page")
        page = doc[0]
        original_text = text_spans(page)
        if sum(span[0] == NOTE for span in original_text) != 1:
            raise RuntimeError("Expected exactly one original annotation text span")
        expected_text = [span for span in original_text if span[0] != NOTE]
        expected_geometry = drawing_geometry(page)
        if len(expected_geometry) != 375:
            raise RuntimeError("Unexpected original figure drawing count")
        expected_rect = tuple(page.rect)
        remove_note(doc)
        check_page(page, expected_geometry, expected_text, expected_rect)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        doc.save(args.output, garbage=4, deflate=True)

    with fitz.open(args.output) as final:
        check_page(final[0], expected_geometry, expected_text, expected_rect)
        final[0].get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False).save(
            args.output.with_suffix(".png")
        )
    print("Removed exactly one annotation text block; no redaction or white overlay.")
    print("All 375 original vector drawings and every unrelated text span are identical.")
    print(f"Preserved source: {args.input}")
    print(f"Wrote: {args.output}")


if __name__ == "__main__":
    main()
