#!/usr/bin/env python3
"""Rebuild the five aggregate author-review CSVs without fitting models.
This transparent reconstruction was written for the 2026-11-08 submission package:
the generator and CSVs referenced by the supplied SI were absent from supplied ZIPs.
Public frozen inputs and a newly recovered aggregate roster audit are used.
"""
from pathlib import Path
import argparse,hashlib,json,platform
import numpy as np
import pandas as pd

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def bools(series):return series.astype(str).str.lower().isin(['true','1'])
def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive-root',type=Path,default=root/'archive_v1.0.2')
    p.add_argument('--coverage-source',type=Path,default=root/'data/provenance/country_roster_coverage_by_venue_year.csv')
    p.add_argument('--output-dir',type=Path,default=root/'data/author_checks')
    a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    input_names=['data/model_inputs/entrant_model_inputs.csv','data/aggregate/accepted_country_credits.csv','results/tables/table_1_analysis_populations.csv','provenance/release_manifest.json']
    manifest=json.loads((a.archive_root/input_names[-1]).read_text())
    for name in input_names[:-1]:assert sha(a.archive_root/name)==manifest[name],name
    f=pd.read_csv(a.archive_root/input_names[0]);observed=bools(f.primary_distance_observed)
    assert observed.equals(f.specter2_title_distance_primary.notna())
    eligible=f.index_year.between(2018,2022);team=f.entry_team_size_mean.ge(2)
    rq=f[eligible&observed&team].copy();rq['history']=bools(rq.entry_with_experienced_top4_coauthor)
    outcomes=['no_recurrence','coauthor_continuity_only','at_least_one_no_index_coauthor']
    counts=[];desc=[];overlap=[]
    groups=[rq[~rq.history],rq[rq.history]]
    lower=max(g.entry_team_size_mean.min() for g in groups);upper=min(g.entry_team_size_mean.max() for g in groups)
    for status,g in zip([0,1],groups):
        x=g.entry_team_size_mean
        for outcome in outcomes:
            n=int(g.exact_plus2_top4.eq(outcome).sum());counts.append({'recent_coauthor_history':status,'outcome':outcome,'n':n,'group_n':len(g),'percent':100*n/len(g)})
        desc.append({'recent_coauthor_history':status,'n':len(g),'mean':x.mean(),'sample_sd':x.std(ddof=1),'median':x.median(),'q25':x.quantile(.25),'q75':x.quantile(.75),'minimum':x.min(),'maximum':x.max()})
        overlap.append({'recent_coauthor_history':status,'n':len(g),'shared_minimum':lower,'shared_maximum':upper,'within_shared_range':int(x.between(lower,upper).sum()),'below_shared_range':int(x.lt(lower).sum()),'above_shared_range':int(x.gt(upper).sum())})
    assert [len(g) for g in groups]==[752,4370]
    assert [r['n'] for r in counts]==[515,141,96,2390,1280,700]
    flow=[('all_entrants',len(f)),('distance_observed',int(observed.sum())),('D1_distance_observed_team_at_least_two',int((observed&team).sum())),('RQ3_complete_horizon',int(eligible.sum())),('RQ3_horizon_distance_observed',int((eligible&observed).sum())),('RQ3_primary',len(rq))]
    assert [n for _,n in flow]==[12094,9639,9521,6704,5207,5122]
    credits=pd.read_csv(a.archive_root/input_names[1]);credits=credits[credits.country_mapping.eq('conservative')].groupby('year')[['fractional','full']].sum()
    roster=pd.read_csv(a.coverage_source).groupby('year')[['roster_papers','country_resolved_papers','unresolved_papers','whole_country_credits']].sum()
    assert np.allclose(credits.fractional,roster.country_resolved_papers,atol=1e-8,rtol=0)
    assert np.allclose(credits.full,roster.whole_country_credits,atol=1e-8,rtol=0)
    coverage=roster.reset_index();coverage['coverage_percent']=100*coverage.country_resolved_papers/coverage.roster_papers
    total={'year':'2018-2024',**{name:int(coverage[name].sum()) for name in roster.columns}}
    total['coverage_percent']=100*total['country_resolved_papers']/total['roster_papers']
    assert total['roster_papers']==26872 and total['country_resolved_papers']==23807 and total['whole_country_credits']==24281
    coverage=pd.concat([coverage,pd.DataFrame([total])],ignore_index=True)
    tables={'rq3_observed_outcomes_by_coauthor_history.csv':pd.DataFrame(counts),'rq3_group_descriptives.csv':pd.DataFrame(desc),'rq3_team_size_overlap.csv':pd.DataFrame(overlap),'cohort_sample_flow.csv':pd.DataFrame(flow,columns=['stage','n']),'country_coverage_by_year.csv':coverage}
    for name,data in tables.items():data.to_csv(a.output_dir/name,index=False,float_format='%.12g')
    provenance={'status':'PASS','generator_origin':'new reconstruction; not recovered original script','models_refitted':False,'archive_commit':'9b8b962eddd87f7279504c3f59d8de34b230e90c','archive_version':'1.0.2','input_sha256':{name:sha(a.archive_root/name) for name in input_names},'coverage_source':{'path':'data/provenance/country_roster_coverage_by_venue_year.csv','sha256':sha(a.coverage_source),'basis':'new aggregate export from retained local paper-level country input, matched to all frozen country credits and original roster; see country_coverage_recovery.json'},'generator_sha256':sha(Path(__file__)),'output_sha256':{name:sha(a.output_dir/name) for name in tables},'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},'limitations':['These are descriptive counts, not re-estimated model predictions.','The newly recovered 2019-2023 roster denominators were not in the original public archive.','The supplied 2026-11-08 author-check outputs are additions, not contents of archive v1.0.2.','Row-level authorship and affiliation records are not redistributed.']}
    (a.output_dir/'author_review_diagnostics_provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    print('PASS: five CSVs and provenance JSON generated; no model refit.')
    print(pd.DataFrame(desc).to_string(index=False));print(coverage.to_string(index=False))
if __name__=='__main__':main()
