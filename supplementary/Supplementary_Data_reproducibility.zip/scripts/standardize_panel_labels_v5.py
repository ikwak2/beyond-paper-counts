#!/usr/bin/env python3
"""Editorial vector-label utility [R], reconstructed for the v5 package.

Reads retained Figure 3 / S1 inputs and standardizes panel letters.
Main Figure 3's tick 1,000 becomes 1000. Current Figures 2 and 4 must use
render_figures_2_4_from_csv.py; this utility never overwrites those assets.
No data, models, axes, lines, markers, colours or error bars are recomputed.
The original archive_v1.0.2 is never read as an output directory or modified.
"""
from pathlib import Path
import argparse, collections, hashlib, json, re
import fitz
import numpy as np

NAMES=['Figure_3_revised.pdf','figure_s1_pri_specification_audit.pdf']

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def geometry(page):
    return [{k:v for k,v in p.items() if k not in {'seqno'}}
            for p in page.get_drawings()]

def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=root/'figures/panel_labels_baseline_v5')
    parser.add_argument('--output-dir',type=Path,default=root/'figures')
    parser.add_argument('--qa-dir',type=Path,default=root/'verification/panel_labels_v5')
    args=parser.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    args.qa_dir.mkdir(parents=True,exist_ok=True)
    # Installed open-source font; the font file is embedded in PDFs, not shipped.
    from matplotlib.font_manager import findfont, FontProperties
    bold=str(findfont(FontProperties(family='DejaVu Sans',weight='bold'),fallback_to_default=False))
    regular=str(findfont(FontProperties(family='DejaVu Sans'),fallback_to_default=False))
    report=[]
    for name in NAMES:
        source=args.input_dir/name;target=args.output_dir/name
        assert source.resolve()!=target.resolve()
        old=fitz.open(source);doc=fitz.open(source);page=doc[0]
        original_geometry=geometry(old[0]);patches=[]
        for block in page.get_text('rawdict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    chars=span['chars'];text=''.join(c['c'] for c in chars)
                    if re.match(r'^[ABC][. ]',text):
                        first=chars[0];selected=chars[:2] if chars[1]['c']=='.' else chars[:1]
                        bbox=fitz.Rect(selected[0]['bbox'])
                        for char in selected[1:]:bbox|=fitz.Rect(char['bbox'])
                        patches.append({'old':''.join(c['c'] for c in selected),'new':first['c'].lower(),
                            'bbox':list(bbox),'origin':first['origin'],
                            'size':span['size'],'color':span['color'],'weight':'bold'})
                    if name=='Figure_3_revised.pdf' and text=='1,000':
                        patches.append({'old':text,'new':'1000','bbox':span['bbox'],
                            'origin':span['origin'],'size':span['size'],
                            'color':span['color'],'weight':'normal'})
                    if name=='Figure_4.pdf' and text=='Q1–Q3 band':
                        patches.append({'old':text,'new':'Q25–Q75 band','bbox':span['bbox'],
                            'origin':span['origin'],'size':span['size'],
                            'color':span['color'],'weight':'normal'})
        assert len(patches)=={'Figure_2_revised.pdf':3,'Figure_3_revised.pdf':4,
                              'Figure_4.pdf':3,'figure_s1_pri_specification_audit.pdf':2}[name]
        for patch in patches:
            rect=fitz.Rect(patch['bbox']);rect.x0+=0.08;rect.x1-=0.08
            page.add_redact_annot(rect,fill=False,cross_out=False)
        page.apply_redactions(images=0,graphics=0,text=0)
        page.insert_font(fontname='PanelBold',fontfile=bold)
        if any(p['weight']=='normal' for p in patches):
            page.insert_font(fontname='PanelRegular',fontfile=regular)
        for patch in patches:
            value=patch['color'];color=((value>>16&255)/255,(value>>8&255)/255,(value&255)/255)
            page.insert_text(patch['origin'],patch['new'],fontsize=patch['size'],
                fontname='PanelBold' if patch['weight']=='bold' else 'PanelRegular',
                color=color,overlay=True)
        # Subset at the source, verifying the same rendered glyphs at 200 dpi.
        before_subset=fitz.open(stream=doc.tobytes(garbage=4,deflate=True),filetype='pdf')
        doc.subset_fonts()
        doc.save(target,garbage=4,deflate=True)
        doc.close();new=fitz.open(target)
        assert before_subset[0].get_pixmap(dpi=200,alpha=False).samples==new[0].get_pixmap(dpi=200,alpha=False).samples,name+' font subset changed pixels'
        before_subset.close()
        assert old[0].rect==new[0].rect
        # The vector paths encode every marker, axis, line and interval endpoint.
        # PDF text removal can normalize tiny float serialization differences;
        # compare coordinates to 0.001 pt and verify every other rendered pixel.
        def norm(v):
            if isinstance(v,float):return round(v,3)
            if isinstance(v,(fitz.Point,fitz.Rect)):return [round(float(x),3) for x in v]
            if isinstance(v,(list,tuple)):return [norm(x) for x in v]
            if isinstance(v,dict):return {k:norm(x) for k,x in v.items()}
            return v
        assert norm(original_geometry)==norm(geometry(new[0])),name+' vector geometry changed'
        scale=3
        p0=old[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
        p1=new[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
        a=np.frombuffer(p0.samples,dtype=np.uint8).reshape(p0.height,p0.width,p0.n)
        b=np.frombuffer(p1.samples,dtype=np.uint8).reshape(p1.height,p1.width,p1.n)
        changed=np.any(a!=b,axis=2);mask=np.zeros(changed.shape,dtype=bool)
        for patch in patches:
            rect=fitz.Rect(patch['bbox'])+(-2,-2,2,2)
            # Equivalent notation may be longer than the original string.
            # Include only its actual glyph extent in the authorized text mask.
            font=fitz.Font(fontfile=bold if patch['weight']=='bold' else regular)
            rect.x1=max(rect.x1,patch['origin'][0]+font.text_length(patch['new'],fontsize=patch['size'])+2)
            y0=max(0,int(rect.y0*scale));y1=min(mask.shape[0],int(rect.y1*scale)+2)
            x0=max(0,int(rect.x0*scale));x1=min(mask.shape[1],int(rect.x1*scale)+2)
            mask[y0:y1,x0:x1]=True
        outside=int(np.count_nonzero(changed & ~mask))
        assert outside==0,(name,'pixels changed outside intended text',outside)
        # No numeric scientific label is altered; only the specified separator.
        numbers=lambda text:collections.Counter(re.findall(r'[-−+]?\d+(?:[.,]\d+)*',text))
        t0=old[0].get_text();t1=new[0].get_text()
        normalized=t0.replace('1,000','1000') if name=='Figure_3_revised.pdf' else t0
        if name=='Figure_4.pdf':normalized=normalized.replace('Q1–Q3 band','Q25–Q75 band')
        assert numbers(normalized)==numbers(t1)
        for span in [s for b in new[0].get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans']]:
            assert span['bbox'][0]>=-0.1 and span['bbox'][2]<=new[0].rect.width+0.1,(name,span['text'])
        row={'file':name,'source_sha256':digest(source),'output_sha256':digest(target),
             'page_size_unchanged':True,'vector_paths_and_coordinates_unchanged_to_0_001pt':True,
             'numeric_labels_unchanged_except_requested_separator':True,
             'quartile_notation_equivalent':True,'embedded_fonts_subset':True,
             'font_subsetting_pixel_differences_200dpi':0,
             'outside_edit_pixel_differences_216dpi':outside,'patches':patches}
        report.append(row);old.close();new.close()
    (args.qa_dir/'validation.json').write_text(json.dumps({'status':'PASS','figures':report},indent=2)+'\n')
    print(json.dumps({'status':'PASS','figures_edited':len(report),'panels_edited':5,'tick_labels_edited':1,'quartile_legend_edited':0}))

if __name__=='__main__':main()
