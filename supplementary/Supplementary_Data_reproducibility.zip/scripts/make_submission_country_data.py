#!/usr/bin/env python3
"""Build the Scientific Reports country-comparison data bundle from the frozen published tables.

Uses frozen country credits at the commit cited by the submitted manuscript.
Does not fit models or modify the repository, main.tex, or fixmain.tex.

On a networked VS Code machine:
  python make_submission_country_data.py --output-dir ./submission_data

If downloaded source files already exist locally:
  python make_submission_country_data.py --source-dir ./frozen_csvs --output-dir ./submission_data
"""

import argparse
import csv
import io
import json
import hashlib
import math
import urllib.request
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

COMMIT = '9b8b962eddd87f7279504c3f59d8de34b230e90c'
BASE = f'https://raw.githubusercontent.com/ikwak2/beyond-paper-counts/{COMMIT}/results/additional_files/'
SOURCES = {
    'series': 'supplement_table2_all_countries_2018_2024.csv',
    'endpoints': 'supplement_table2_all_countries_endpoints.csv',
}

EXPECTED_CODES = {'US', 'CN', 'GB', 'CA', 'FR', 'DE', 'CH', 'IL', 'JP', 'KR', 'IN'}
EXPECTED_2018 = {'US': 750, 'CN': 109, 'GB': 108, 'CA': 89, 'FR': 56,
                 'DE': 54, 'CH': 51, 'IL': 34, 'JP': 29, 'KR': 27, 'IN': 12}
EXPECTED_2024 = {'US': 2201, 'CN': 1868, 'GB': 305, 'CA': 212, 'FR': 138,
                 'DE': 284, 'CH': 188, 'IL': 95, 'JP': 79, 'KR': 228, 'IN': 32}


def fetch_bytes(source_dir, filename):
    if source_dir is not None:
        path = source_dir / filename
        if not path.is_file():
            raise FileNotFoundError(f'Missing frozen source: {path}')
        return path.read_bytes()
    url = BASE + filename
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            return resp.read()
    except Exception as exc:
        raise RuntimeError(f'Cannot retrieve frozen source {url}. Download it manually, '
                           f'then rerun with --source-dir. Underlying error: {exc}') from exc


def load_csv(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))


def v(row, key):
    return float(row[key])


def number_or_empty(x):
    if x is None or not math.isfinite(float(x)):
        return ''
    return format(float(x), '.12g')


def save_csv(path, rows, columns):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--source-dir', type=Path, default=None,
                   help='Directory containing the two frozen CSV source files; skips network')
    p.add_argument('--output-dir', type=Path, default=Path('submission_data'))
    args = p.parse_args()
    outdir = args.output_dir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    raw = {key: fetch_bytes(args.source_dir, name) for key, name in SOURCES.items()}
    series = load_csv(raw['series'])
    endpoints = load_csv(raw['endpoints'])
    assert len(series) == 210*7, f'Expected 1,470 annual country records, got {len(series)}'
    assert len(endpoints) == 210, f'Expected 210 endpoints, got {len(endpoints)}'
    assert Counter(int(r['year']) for r in series) == {y: 210 for y in range(2018,2025)}
    assert len(set(r['country_code'] for r in series)) == 210
    assert len(set(r['country_code'] for r in endpoints)) == 210

    by_yc = {(int(r['year']),r['country_code']): r for r in series}
    assert len(by_yc) == 1470
    totals = {}
    for year in range(2018,2025):
        block = [r for r in series if int(r['year'])==year]
        ac = {r['accepted_credit_total'] for r in block}
        ai = {r['ai_output_credit_total'] for r in block}
        assert len(ac)==len(ai)==1
        av=int(round(float(next(iter(ac)))))
        bv=int(round(float(next(iter(ai)))))
        assert sum(int(float(r['accepted_paper_credits'])) for r in block)==av
        assert sum(int(float(r['ai_output_credits'])) for r in block)==bv
        totals[year]=(av,bv)

    # Baseline-only 2018 selection (with ties): accepted top-10 union output top-3.
    baseline = {r['country_code']:r for r in series if int(r['year'])==2018}
    a_vals=sorted((v(r,'accepted_paper_credits') for r in baseline.values()), reverse=True)
    b_vals=sorted((v(r,'ai_output_credits') for r in baseline.values()), reverse=True)
    a_cut, b_cut = a_vals[9], b_vals[2]
    selected={code for code,r in baseline.items()
              if v(r,'accepted_paper_credits')>=a_cut or v(r,'ai_output_credits')>=b_cut}
    assert selected == EXPECTED_CODES, f'Baseline selected {selected}, not expected {EXPECTED_CODES}'
    order=sorted(selected,key=lambda code:(-v(baseline[code],'accepted_paper_credits'),code))

    for code in selected:
        assert int(v(by_yc[(2018,code)],'accepted_paper_credits'))==EXPECTED_2018[code]
        assert int(v(by_yc[(2024,code)],'accepted_paper_credits'))==EXPECTED_2024[code]

    # Check two source exports agree at their endpoints.
    by_code = {r['country_code']:r for r in endpoints}
    for code in selected:
        e=by_code[code]
        for y in (2018,2024):
            s=by_yc[(y,code)]
            assert abs(v(e,f'accepted_paper_credits_{y}')-v(s,'accepted_paper_credits'))<1e-8
            assert abs(v(e,f'ai_output_credits_{y}')-v(s,'ai_output_credits'))<1e-8
            assert abs(v(e,f'pri_{y}')-v(s,'pri'))<1e-8

    data_files = []
    # Keep precision of primary frozen ratios; NEVER use rounded manuscript table values as inputs.
    country_rows=[]
    for year in range(2018,2025):
        for code in order:
            r=by_yc[(year,code)]
            country_rows.append({
                'year':year,'country_code':code,'country':r['country_name'],
                'accepted_country_credits':r['accepted_paper_credits'],
                'all_country_credits':r['accepted_credit_total'],
                'accepted_share_pct':number_or_empty(100*v(r,'accepted_share')),
                'AI_output_credits':r['ai_output_credits'],
                'AI_output_country_credit_total':r['ai_output_credit_total'],
                'AI_output_share_pct':number_or_empty(100*v(r,'output_share')),
                'PRI':r['pri'], 'PRI_status':r['pri_status']
            })
    name='country_case_timeseries.csv'
    save_csv(outdir/name,country_rows,list(country_rows[0]));data_files.append(name)

    country_ep=[]
    for code in order:
        e=by_code[code]
        ac18=v(e,'accepted_paper_credits_2018');ac24=v(e,'accepted_paper_credits_2024')
        sh18=v(e,'accepted_share_2018');sh24=v(e,'accepted_share_2024')
        country_ep.append({
            'country_code':code,'country':e['country_name'],
            'accepted_credits_2018':number_or_empty(ac18),
            'accepted_credits_2024':number_or_empty(ac24),
            'accepted_share_pct_2018':number_or_empty(sh18*100),
            'accepted_share_pct_2024':number_or_empty(sh24*100),
            'AI_output_credits_2018':e['ai_output_credits_2018'],
            'AI_output_credits_2024':e['ai_output_credits_2024'],
            'AI_output_share_pct_2018':number_or_empty(v(e,'output_share_2018')*100),
            'AI_output_share_pct_2024':number_or_empty(v(e,'output_share_2024')*100),
            'PRI_2018':e['pri_2018'],'PRI_2024':e['pri_2024'],
            'accepted_credit_growth_factor':number_or_empty(ac24/ac18) if ac18 else '',
            'accepted_share_change_ratio':number_or_empty(sh24/sh18) if sh18 else ''
        })
    name='country_case_endpoints.csv'
    save_csv(outdir/name,country_ep,list(country_ep[0]));data_files.append(name)

    name='country_all_timeseries.csv'
    save_csv(outdir/name,series,list(series[0]));data_files.append(name)

    all_ep=[]
    for e in endpoints:
        a18=v(e,'accepted_paper_credits_2018');a24=v(e,'accepted_paper_credits_2024')
        s18=v(e,'accepted_share_2018');s24=v(e,'accepted_share_2024')
        x=dict(e)
        x['accepted_credit_growth_factor']=number_or_empty(a24/a18) if a18 else ''
        x['accepted_share_change_ratio']=number_or_empty(s24/s18) if s18 else ''
        x['growth_defined']=bool(a18)
        all_ep.append(x)
    name='country_all_endpoints.csv'
    save_csv(outdir/name,all_ep,list(all_ep[0]));data_files.append(name)

    totals_rows=[{'year':y,'accepted_country_credit_total':totals[y][0],
                  'AI_output_country_credit_total':totals[y][1]} for y in range(2018,2025)]
    name='country_annual_totals.csv'
    save_csv(outdir/name,totals_rows,list(totals_rows[0]));data_files.append(name)

    select_rows=[]
    for code,r in baseline.items():
        a=v(r,'accepted_paper_credits');b=v(r,'ai_output_credits')
        rank_a=1+sum(v(other,'accepted_paper_credits')>a for other in baseline.values())
        rank_b=1+sum(v(other,'ai_output_credits')>b for other in baseline.values())
        select_rows.append({'country_code':code,'country':r['country_name'],
                            'accepted_credits_2018':number_or_empty(a),
                            'AI_output_credits_2018':number_or_empty(b),
                            'accepted_2018_rank_with_ties':rank_a,
                            'AI_output_2018_rank_with_ties':rank_b,
                            'selected': code in selected,
                            'selection_rule':'2018 top-10 accepted or top-3 AI output, including ties'})
    name='country_selection.csv'
    select_rows.sort(key=lambda r:(not r['selected'],r['accepted_2018_rank_with_ties'],r['country']))
    save_csv(outdir/name,select_rows,list(select_rows[0]));data_files.append(name)

    readme=f'''# Scientific Reports: frozen country-comparison data

Generated from manuscript-cited public GitHub commit `{COMMIT}`.
Source files:
- `{SOURCES['series']}`: 1,470 country-year records (210 countries x 7 years).
- `{SOURCES['endpoints']}`: 210 country endpoint records.

11-country selection: top ten by 2018 accepted credits, union top three by 2018 observed AI-output credits (ties retained; 11 in this frozen data). No endpoint-change selection.

All shares use **all observed country credits**, not the subtotal of the 11 selected countries. The accepted-paper numerator is conservative-mapping first-listed-author whole counting; the observed-AI denominator is all-author work-country whole counting. PRI is a ratio of these shares, not an acceptance rate. Undefined growth when 2018 credit is zero is left blank.

Files:
- `country_case_timeseries.csv` (77 rows): 11 selected countries x 7 years, including accepted/output credits, shares and PRI.
- `country_case_endpoints.csv` (11 rows): 2018/2024 endpoints, country credit growth, PRI.
- `country_all_timeseries.csv` (1,470 rows): full frozen annual primary specification.
- `country_all_endpoints.csv` (210 rows): all country endpoints plus derived growth/status.
- `country_annual_totals.csv` (7 rows): yearly denominators for accepted and AI-output credits.
- `country_selection.csv` (210 rows): reproducible baseline ranks/selection flag.

This data bundle is separate from `Additional_file_2.zip`, which must also be sourced from the **existing frozen archive** or project original. This script neither rebuilds nor fabricates that original supplementary package.
'''
    (outdir/'DATA_DICTIONARY.md').write_text(readme,encoding='utf-8')

    manifest={'source_commit':COMMIT,'source_urls':{k:BASE+v for k,v in SOURCES.items()},
              'source_sha256':{k:hashlib.sha256(b).hexdigest() for k,b in raw.items()},
              'selected_codes':order,'country_count':210,'annual_records':1470,
              'yearly_totals':totals_rows,'created_utc':datetime.now(timezone.utc).isoformat(),
              'file_sha256':{f:hashlib.sha256((outdir/f).read_bytes()).hexdigest() for f in data_files}}
    (outdir/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

    zip_path = outdir/'Supplementary_Data_country_comparison.zip'
    with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in data_files+['DATA_DICTIONARY.md','SOURCE_MANIFEST.json']:
            z.write(outdir/f,arcname=f)
    print('OK:',zip_path)
    print('210 countries x 7 years; 11-country selection validated')
    print('Archive is separate from the required original Additional_file_2.zip')

if __name__=='__main__':
    main()
