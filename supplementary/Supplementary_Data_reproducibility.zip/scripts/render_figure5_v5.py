#!/usr/bin/env python3
"""Editorial renderer only: read frozen CSVs; never fit models or bootstrap.
Run from any directory. --bundle-root defaults to the parent of scripts/.
"""
from pathlib import Path
import argparse,csv,hashlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np

PATHS=['no_recurrence','coauthor_continuity_only','at_least_one_no_index_coauthor']
LABELS=['No record','All papers include at least one entry coauthor','At least one paper with no entry coauthor']
def main():
 p=argparse.ArgumentParser();p.add_argument('--bundle-root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--output-dir',type=Path);a=p.parse_args()
 root=a.bundle_root;out=a.output_dir or root/'figures';out.mkdir(parents=True,exist_ok=True)
 paths=[root/'archive_v1.0.2/data/distance'/('rq3_exact_plus2_'+kind+'.csv') for kind in ['probabilities','contrasts']]
 read=lambda p:list(csv.DictReader(p.open()))
 prob=[r for r in read(paths[0]) if r['specification']=='semantic_primary']
 con=[r for r in read(paths[1]) if r['specification']=='semantic_primary' and r['contrast_family']=='experienced_minus_no_experienced']
 assert len(prob)==12 and len(con)==6 and {r['n'] for r in prob}=={'5122'}
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 fig=plt.figure(figsize=(4.91,4.9));ax=fig.add_axes([.16,.63,.80,.27]);bx=fig.add_axes([.38,.23,.58,.235])
 scenarios=[(q,e) for q in ['Q25','Q75'] for e in ['False','True']];bottom=np.zeros(4)
 for pathway,label,color in zip(PATHS,LABELS,['#B8B0AD','#E15759','#4C78A8']):
  values=np.array([float(next(r for r in prob if r['distance_level']==q and r['experienced_coauthor']==e and r['pathway']==pathway)['adjusted_probability']) for q,e in scenarios])
  ax.bar(range(4),values,bottom=bottom,width=.72,color=color,label=label);bottom+=values
 np.testing.assert_allclose(bottom,1,atol=1e-10)
 ax.set(ylim=(0,1),ylabel='Standardized pathway\nprobability')
 ax.set_xticks(range(4),[f"{q}\n{'With' if e=='True' else 'No'}\nrecent-history\ncoauthor" for q,e in scenarios])
 ax.set_title('a  Exact +2 pathway probabilities',loc='left',fontweight='bold',pad=7)
 segments=[];plotted=[]
 for q,shift,color,marker in [('Q25',.12,'#4C78A8','o'),('Q75',-.12,'#E17C05','s')]:
  d=[next(r for r in con if r['distance_level']==q and r['pathway']==pathway) for pathway in PATHS]
  est=np.array([100*float(r['probability_difference']) for r in d]);lo=np.array([100*float(r['ci_low']) for r in d]);hi=np.array([100*float(r['ci_high']) for r in d]);y=np.arange(3)[::-1]+shift
  bx.errorbar(est,y,xerr=[est-lo,hi-est],fmt=marker,color=color,capsize=3,markersize=4,label=q)
  segments.extend([(l,h,yy) for l,h,yy in zip(lo,hi,y)]);plotted+=d
 bx.axvline(0,color='#455A64',ls='--',lw=.8)
 bx.set_yticks([2,1,0],['No record','All follow-up papers\ninclude an entry coauthor','At least one follow-up\npaper without entry coauthors'])
 bx.set(xlim=(-19,15),ylim=(-.55,2.55),xlabel='With − without recent-history coauthor\n(percentage points)');bx.set_xticks([-15,-10,-5,0,5,10,15])
 legend=bx.legend(frameon=False,loc='lower right',bbox_to_anchor=(1,1.03),ncol=2,handlelength=1,columnspacing=.8,borderaxespad=0)
 panel_b_title=fig.text(.055,.48,'b  Recent-history coauthor contrasts',weight='bold',fontsize=8.5)
 handles,labels=ax.get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.53,.012),frameon=False,labelspacing=.3,handlelength=1.3)
 fig.canvas.draw();renderer=fig.canvas.get_renderer();legendbox=legend.get_window_extent(renderer)
 rowboxes=[label.get_window_extent(renderer) for label in bx.get_yticklabels()]
 row_gaps=[rowboxes[i].y0-rowboxes[i+1].y1 for i in range(len(rowboxes)-1)]
 assert min(row_gaps)>4,('Row labels have insufficient vertical separation',row_gaps)
 for text in fig.findobj(Text):
  if text.get_visible() and text.get_text():
   box=text.get_window_extent(renderer)
   assert fig.bbox.contains(box.x0,box.y0) and fig.bbox.contains(box.x1,box.y1),(text.get_text(),box.bounds)
   assert text.get_fontfamily()==['DejaVu Sans']
 assert all(not panel_b_title.get_window_extent(renderer).overlaps(label.get_window_extent(renderer)) for label in ax.get_xticklabels())
 for lo,hi,y in segments:
  assert -19<lo<=hi<15
  p0=bx.transData.transform((lo,y));p1=bx.transData.transform((hi,y))
  assert bx.bbox.contains(*p0) and bx.bbox.contains(*p1)
  # Include cap height and marker radius in the legend-intersection check.
  from matplotlib.transforms import Bbox
  assert not legendbox.overlaps(Bbox.from_extents(p0[0]-5,p0[1]-5,p1[0]+5,p1[1]+5))
 fig.savefig(out/'Figure_5_revised.pdf',facecolor='white',metadata={'Title':'Recent coauthor history and exact +2 reappearance'})
 fig.savefig(out/'Figure_5_revised.png',dpi=220,facecolor='white')
 report={'status':'PASS','scope':'frozen CSV rendering, no statistical re-estimation','inputs':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'probability_rows':prob,'contrast_rows':plotted,'xlim':[-19,15],'maximum_upper_ci_percentage_points':max(h for l,h,y in segments),'all_interval_endpoints_inside_axes':True,'legend_disjoint_from_interval_caps_and_markers':True,'all_text_inside_canvas':True,'all_text_DejaVu_Sans':True,'output_sha256':hashlib.sha256((out/'Figure_5_revised.pdf').read_bytes()).hexdigest()}
 report['minimum_row_label_gap_pixels_at_100dpi']=min(row_gaps)
 (out/'figure5_v5_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['probability_rows','contrast_rows']},indent=2))
if __name__=='__main__':main()
