#!/usr/bin/env python3
"""Rebuild revised Figures 1 and 3 without refitting any statistical model.

Run from VS Code's terminal:
    python scripts/rebuild_figures.py

Dependencies: matplotlib and numpy.

Provenance
----------
Figure 1 sample counts are transcribed from the supplied manuscript Methods
5.3--5.4 and Supplementary Table S8.  Arrows show record construction and
sample restrictions only.  In particular, D1 uses 9,521 entrants, not the
9,639 entrants with observed title distance.

Figure 3 endpoints are transcribed verbatim from Supplementary Table S7(a,c)
in the supplied supplementary-information TeX source.  Accepted shares are
the published percentages (two decimal places); PRI values are the published
estimates (three decimal places).  No values have been digitized from a chart,
inferred for a missing year, or recalculated using rounded percentages.

The original country selection and order are retained.  The new PRI panel
makes the Switzerland share-decrease/PRI-increase comparison visible.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Rectangle
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator
import numpy as np


# Values printed in Supplementary Table S7.  Do not replace them with values
# recovered from rounded share ratios.
COUNTRY_ENDPOINTS = [
    # Country, credits18, credits24, share18 (%), share24 (%), PRI18, PRI24
    ("United States", 750, 2201, 51.02, 33.34, 3.262, 2.696),
    ("China", 109, 1868, 7.41, 28.29, 0.480, 1.194),
    ("United Kingdom", 108, 305, 7.35, 4.62, 1.607, 1.268),
    ("Canada", 89, 212, 6.05, 3.21, 2.493, 1.534),
    ("France", 56, 138, 3.81, 2.09, 0.936, 0.881),
    ("Germany", 54, 284, 3.67, 4.30, 0.842, 1.289),
    ("Switzerland", 51, 188, 3.47, 2.85, 3.508, 3.695),
    ("Israel", 34, 95, 2.31, 1.44, 3.257, 3.108),
    ("Japan", 29, 79, 1.97, 1.20, 0.532, 0.470),
    ("South Korea", 27, 228, 1.84, 3.45, 1.320, 1.906),
    ("India", 12, 32, 0.82, 0.48, 0.160, 0.064),
]

INK = "#243746"
BLUE = "#12789A"
ORANGE = "#B87026"
TEAL = "#397D79"
PURPLE = "#77678D"
EDGE = "#C6D0D7"
LIGHT = "#F4F7F8"
ROW = "#F0F3F5"


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9.5,
            "text.color": INK,
            "axes.labelcolor": INK,
            "xtick.color": INK,
            "ytick.color": INK,
            "axes.edgecolor": "#72818A",
            "axes.linewidth": 0.65,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.facecolor": "white",
        }
    )


def save_figure(fig: plt.Figure, destination: Path, stem: str) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    fig.savefig(
        destination / f"{stem}.pdf",
        bbox_inches="tight",
        pad_inches=0.035,
        metadata={
            "Title": stem,
            "Subject": "Revised figure using reported manuscript values",
            "Creator": "scripts/rebuild_figures.py (Matplotlib)",
        },
    )
    fig.savefig(
        destination / f"{stem}.png",
        dpi=220,
        bbox_inches="tight",
        pad_inches=0.035,
    )
    plt.close(fig)


def draw_box(
    ax: plt.Axes,
    center_x: float,
    center_y: float,
    width: float,
    height: float,
    color: str,
    lines: list[tuple[str, float, str]],
    fill: str = "white",
) -> None:
    """Draw a text box; font sizes are in points, coordinates in inches."""
    x, y = center_x - width / 2, center_y - height / 2
    ax.add_patch(Rectangle((x, y), width, height, fc=fill, ec=EDGE, lw=0.8, zorder=2))
    ax.plot([x, x + width], [y + height, y + height], color=color, lw=1.75, zorder=3)
    line_step = 0.215
    y_start = center_y + line_step * (len(lines) - 1) / 2
    for j, (text, font_size, weight) in enumerate(lines):
        ax.text(
            center_x,
            y_start - j * line_step,
            text,
            ha="center",
            va="center",
            fontsize=font_size,
            fontweight=weight,
            zorder=4,
        )


def arrow(ax: plt.Axes, start: tuple[float, float], end: tuple[float, float]) -> None:
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=8,
            linewidth=0.85,
            color="#82919A",
            shrinkA=2.0,
            shrinkB=2.0,
            zorder=1,
        )
    )


def figure_1(destination: Path) -> None:
    fig = plt.figure(figsize=(6.75, 5.15))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 6.75)
    ax.set_ylim(0, 5.15)
    ax.axis("off")

    # The top node links to country records and the full entrant cohort.
    draw_box(
        ax, 3.375, 4.76, 4.28, 0.64, INK,
        [("ICML and NeurIPS, 2018-2024", 10.7, "bold"),
         ("26,872 accepted papers", 10.2, "normal")],
        fill=LIGHT,
    )

    xs = (1.06, 3.345, 5.635)
    w = 2.02
    for x, title, color in zip(
        xs,
        ("Representation", "Entry", "Reappearance"),
        (ORANGE, TEAL, PURPLE),
    ):
        ax.text(x, 4.03, title, ha="center", va="center", fontsize=10.3,
                fontweight="bold", color=color, zorder=6,
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 2.5})

    # Construction arrows are intentionally distinct from the research labels.
    # Country-credit records and entrant histories are separate observational units.
    ax.plot([xs[0], xs[1]], [4.29, 4.29], color="#82919A", lw=0.85, zorder=1)
    ax.plot([xs[1], xs[1]], [4.44, 4.29], color="#82919A", lw=0.85, zorder=1)
    arrow(ax, (xs[0], 4.29), (xs[0], 3.79))
    arrow(ax, (xs[1], 4.29), (xs[1], 3.79))

    draw_box(
        ax, xs[0], 3.31, w, 0.96, ORANGE,
        [("Accepted country credits", 9.3, "bold"),
         ("First-listed authors", 9.0, "normal"),
         ("Observed affiliation countries", 8.45, "normal")],
    )
    draw_box(
        ax, xs[1], 3.31, w, 0.96, TEAL,
        [("Observed entrants", 9.5, "bold"),
         ("12,094", 12.0, "bold"),
         ("2018-2024 entry years", 9.0, "normal")],
    )
    draw_box(
        ax, xs[2], 3.31, w, 0.96, PURPLE,
        [("Eligible entry cohorts", 9.35, "bold"),
         ("6,704", 12.0, "bold"),
         ("2018-2022; complete +2 horizon", 8.4, "normal")],
    )
    arrow(ax, (xs[1] + w / 2, 3.31), (xs[2] - w / 2, 3.31))

    draw_box(
        ax, xs[0], 1.99, w, 1.00, ORANGE,
        [("Production-adjusted", 9.3, "normal"),
         ("representation (RQ1)", 9.3, "bold"),
         ("44 observed-data specifications", 8.5, "normal")],
        fill="#FCFAF6",
    )
    arrow(ax, (xs[0], 2.83), (xs[0], 2.49))

    draw_box(
        ax, xs[1], 1.99, w, 1.00, TEAL,
        [("Title distance (RQ2)", 9.5, "bold"),
         ("9,639 (79.7%)", 11.4, "bold"),
         ("Eligible prior-title portfolios", 8.6, "normal")],
        fill="#F6FAF9",
    )
    arrow(ax, (xs[1], 2.83), (xs[1], 2.49))
    draw_box(
        ax, xs[2], 1.99, w, 1.00, PURPLE,
        [("Observed title distance", 9.35, "bold"),
         ("5,207", 12.0, "bold"),
         ("Eligible prior-title portfolios", 8.6, "normal")],
    )
    arrow(ax, (xs[2], 2.83), (xs[2], 2.49))

    draw_box(
        ax, xs[1], 0.64, w, 1.00, TEAL,
        [("Coauthor diagnostic (D1)", 9.1, "bold"),
         ("9,521", 12.0, "bold"),
         ("Mean entry-team size ≥ 2", 8.7, "normal")],
        fill="#F6FAF9",
    )
    arrow(ax, (xs[1], 1.49), (xs[1], 1.14))
    draw_box(
        ax, xs[2], 0.64, w, 1.00, PURPLE,
        [("Exact +2 pathways (RQ3)", 9.15, "bold"),
         ("5,122", 12.0, "bold"),
         ("Mean entry-team size ≥ 2", 8.7, "normal")],
        fill="#F9F7FA",
    )
    arrow(ax, (xs[2], 1.49), (xs[2], 1.14))

    # The relation type is documented in the accompanying figure caption.
    save_figure(fig, destination, "Figure_1_revised")


def figure_3(destination: Path) -> None:
    countries = [r[0] for r in COUNTRY_ENDPOINTS]
    data = np.asarray([r[1:] for r in COUNTRY_ENDPOINTS], dtype=float)
    y = np.arange(len(countries), dtype=float)

    fig, axes = plt.subplots(
        1, 3, figsize=(6.95, 4.95), sharey=True,
        gridspec_kw={"width_ratios": [1.0, 1.0, 1.0]},
    )
    fig.subplots_adjust(left=0.205, right=0.985, top=0.875, bottom=0.195, wspace=0.25)

    titles = ("A  Accepted credits", "B  Accepted share", "C  Representation")
    xlabels = ("Country credits (log)", "Share (%)", "PRI")
    for j, ax in enumerate(axes):
        ax.set_title(titles[j], fontsize=10.0, fontweight="bold", loc="left", pad=12)
        ax.set_xlabel(xlabels[j], fontsize=9.2, labelpad=6)
        for k in range(len(countries)):
            if k % 2 == 0:
                ax.axhspan(k - 0.44, k + 0.44, fc=ROW, ec="none", zorder=0)
        for k in range(len(countries)):
            v18, v24 = data[k, j * 2 : j * 2 + 2]
            ax.plot([v18, v24], [k, k], lw=1.45, color="#B3C0C8",
                    solid_capstyle="round", zorder=2)
        ax.scatter(data[:, j * 2], y, marker="o", s=21, facecolors="white",
                   edgecolors=ORANGE, linewidths=1.05, zorder=4)
        ax.scatter(data[:, j * 2 + 1], y, marker="D", s=18.5, facecolors=BLUE,
                   edgecolors=BLUE, linewidths=0.45, zorder=5)
        ax.set_ylim(len(countries) - 0.5, -0.5)
        ax.set_yticks(y)
        ax.tick_params(axis="y", length=0, pad=8, labelsize=9.1)
        ax.tick_params(axis="x", labelsize=8.7, length=3.2, width=0.65)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)

    axes[0].set_yticklabels(countries)
    axes[0].set_xscale("log")
    axes[0].set_xlim(8.0, 3200.0)
    axes[0].xaxis.set_major_locator(FixedLocator([10, 100, 1000]))
    axes[0].xaxis.set_major_formatter(FuncFormatter(lambda x, _p: f"{int(x):,}"))
    axes[0].xaxis.set_minor_locator(NullLocator())

    axes[1].set_xlim(-2.0, 56.0)
    axes[1].set_xticks([0, 25, 50])

    axes[2].set_xlim(-0.12, 4.02)
    axes[2].set_xticks([0, 1, 2, 3, 4])
    axes[2].axvline(1.0, color="#8998A1", lw=0.8, linestyle=(0, (3, 3)), zorder=1)

    handles = [
        Line2D([0], [0], marker="o", markersize=5.2, ls="none", markerfacecolor="white",
               markeredgecolor=ORANGE, markeredgewidth=1.1, label="2018"),
        Line2D([0], [0], marker="D", markersize=4.6, ls="none", markerfacecolor=BLUE,
               markeredgecolor=BLUE, label="2024"),
        Line2D([0], [0], color="#8998A1", lw=0.8, linestyle=(0, (3, 3)), label="PRI = 1"),
    ]
    fig.legend(handles=handles, ncol=3, frameon=False, fontsize=9.0,
               loc="lower center", bbox_to_anchor=(0.57, 0.025),
               handletextpad=0.55, columnspacing=1.8)
    save_figure(fig, destination, "Figure_3_revised")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--outdir", type=Path,
        default=Path(__file__).resolve().parents[1] / "figures",
        help="Output directory for vector PDFs and PNG previews",
    )
    args = parser.parse_args()
    configure_style()
    figure_1(args.outdir)
    figure_3(args.outdir)
    print(f"Wrote revised Figures 1 and 3 to {args.outdir.resolve()}")


if __name__ == "__main__":
    main()
