#!/usr/bin/env python3
"""Fix the RQ3 pathway labels while preserving the original scientific figure.

Usage from the project directory:
    python scripts/fix_rq3_labels.py

Dependencies: PyMuPDF and matplotlib (for the installed DejaVu Sans font).

Only six original PDF text blocks are removed.  The corresponding labels are
inserted with a separately embedded font, without PDF redaction or opaque
rectangles.  All original drawing operators, bars, point estimates, confidence
intervals, ticks, legend swatches, and unrelated text remain unchanged.

This avoids mutating shared font resources, which can remove unrelated glyphs
when redaction is applied to a nested figure with subset fonts.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re

import fitz
from matplotlib.font_manager import findfont


# Verified text baselines in the figure's original Matplotlib Form XObject.
# Coordinates are native PDF points and are not inferred data values.
REPLACED_BLOCKS = (
    ("57.2593", "116.8182451172"),       # outcome 2, first line
    ("69.22805", "107.8118974609"),    # outcome 2, second line
    ("47.368675", "90.0737289882"),    # outcome 3, first line
    ("53.66555", "81.0673813319"),     # outcome 3, second line
    ("131.3656", "19.342840625"),      # legend, outcome 2
    ("131.3656", "9.9629578125"),      # legend, outcome 3
)

OLD_TEXT = {
    "Entry-coauthor", "papers only", "≥1 paper without", "entry coauthors",
    "Entry-coauthor papers only", "≥1 paper without entry coauthors",
}


def source_form(doc: fitz.Document) -> tuple[int, str]:
    found = []
    for xref, *_ in doc[0].get_xobjects():
        raw = doc.xref_stream(xref)
        if raw and b"62.830145 220.5 m" in raw and b"179.9252394966 145.4958580645 cm /M0 Do" in raw:
            found.append((xref, raw.decode("latin-1")))
    if len(found) != 1:
        raise ValueError(f"Expected one original RQ3 form stream, found {len(found)}")
    return found[0]


def remove_text_at(stream: str, x: str, y: str) -> str:
    pattern = re.compile(
        r"(q\s+1 0 -0 1 " + re.escape(x) + r" " + re.escape(y)
        + r" cm\s+)BT(.*?)ET(\s+Q)", re.DOTALL
    )
    if len(pattern.findall(stream)) != 1:
        raise ValueError(f"Expected one text block at ({x}, {y})")
    return pattern.sub(lambda m: m.group(1) + "BT\nET" + m.group(3), stream)


def text_spans(page: fitz.Page) -> list[tuple]:
    return [
        (s["text"], tuple(round(v, 4) for v in s["bbox"]), s["font"], round(s["size"], 5))
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        for s in line.get("spans", [])
    ]


def geometry(page: fitz.Page) -> list[tuple]:
    """Retain exact path geometry, including scientific marks and axes."""
    return [
        (
            drawing["type"],
            tuple(drawing["rect"]),
            repr(drawing["items"]),
            drawing.get("color"),
            drawing.get("fill"),
            drawing.get("width"),
            drawing.get("dashes"),
        )
        for drawing in page.get_drawings()
    ]


def add_right_aligned_lines(
    page: fitz.Page,
    font: fitz.Font,
    lines: tuple[str, ...],
    *,
    right_edge: float,
    center_y: float,
    fontsize: float = 7.0,
    leading: float = 8.0,
) -> None:
    # Center the complete typographic box around the original pathway row.
    first_baseline = (
        center_y - leading * (len(lines) - 1) / 2
        + fontsize * (font.ascender + font.descender) / 2
    )
    for i, text in enumerate(lines):
        width = font.text_length(text, fontsize=fontsize)
        if right_edge - width < 15:
            raise ValueError("A pathway label would exceed the available left margin")
        page.insert_text(
            (right_edge - width, first_baseline + i * leading), text,
            fontname="RQ3LabelFont", fontsize=fontsize, color=(0, 0, 0), overlay=True,
        )


def verify_unchanged_text(before: list[tuple], after: list[tuple]) -> None:
    for span in before:
        if span[0] not in OLD_TEXT and span not in after:
            raise ValueError(f"An unrelated original text span was altered: {span}")


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=project / "figures/Figure_5_original.pdf")
    parser.add_argument("--output", type=Path, default=project / "figures/Figure_5_revised.pdf")
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        raise ValueError("Keep the original figure separate from the revised output")

    with fitz.open(args.input) as doc:
        if len(doc) != 1:
            raise ValueError("Expected a one-page figure")
        page = doc[0]
        before_geometry = geometry(page)
        if len(before_geometry) != 74:
            raise ValueError(f"Unexpected original drawing count: {len(before_geometry)}")
        before_text = text_spans(page)
        xref, original = source_form(doc)
        revised = original
        for x, y in REPLACED_BLOCKS:
            revised = remove_text_at(revised, x, y)

        # After removing text, the original non-text stream is byte-identical.
        strip_text = lambda s: re.sub(r"BT.*?ET", "", s, flags=re.DOTALL)
        if strip_text(revised) != strip_text(original):
            raise ValueError("A non-text PDF operator was modified")
        doc.update_stream(xref, revised.encode("latin-1"))

        font_path = str(findfont("DejaVu Sans", fallback_to_default=False))
        font = fitz.Font(fontfile=font_path)
        page.insert_font(fontname="RQ3LabelFont", fontfile=font_path)
        add_right_aligned_lines(
            page, font, ("All papers include", "at least one", "entry coauthor"),
            right_edge=118.08, center_y=221.991272,
        )
        add_right_aligned_lines(
            page, font, ("At least one paper", "with no", "entry coauthor"),
            right_edge=118.08, center_y=248.626938,
        )

        for text, baseline in (
            ("All papers include at least one entry coauthor", 317.798889),
            ("At least one paper with no entry coauthor", 327.140625),
        ):
            x, size = 136.167938, 7.469475
            if x + font.text_length(text, fontsize=size) > 353:
                raise ValueError("The revised legend label would exceed the right margin")
            page.insert_text(
                (x, baseline), text, fontname="RQ3LabelFont", fontsize=size,
                color=(0, 0, 0), overlay=True,
            )

        if geometry(page) != before_geometry:
            raise ValueError("Scientific geometry changed during label insertion")
        verify_unchanged_text(before_text, text_spans(page))
        if any(s[0] in OLD_TEXT for s in text_spans(page)):
            raise ValueError("An obsolete pathway label remains in extracted text")

        args.output.parent.mkdir(parents=True, exist_ok=True)
        doc.save(args.output, garbage=4, deflate=True)

    with fitz.open(args.output) as final:
        if geometry(final[0]) != before_geometry:
            raise ValueError("Saved PDF no longer has the original scientific geometry")
        verify_unchanged_text(before_text, text_spans(final[0]))
        text = final[0].get_text()
        for required in (
            "No record", "With", "No", "0.6",
            "All papers include at least one entry coauthor",
            "At least one paper with no entry coauthor",
        ):
            if required not in text:
                raise ValueError(f"Expected text is missing: {required}")
        final[0].get_pixmap(matrix=fitz.Matrix(3, 3)).save(args.output.with_suffix(".png"))
    print("All 74 original vector drawings, including bars, points and intervals, are identical.")
    print("All unrelated original text spans and font resources are preserved.")
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
