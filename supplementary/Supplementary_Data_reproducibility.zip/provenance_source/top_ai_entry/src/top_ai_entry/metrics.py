from __future__ import annotations

import math
import re
from collections import defaultdict
from typing import Iterable

import numpy as np
import pandas as pd


LLM_TITLE_PATTERN = re.compile(
    r"\b("
    r"large language models?|"
    r"language models?|"
    r"chatgpt|"
    r"generative ai|"
    r"foundation models?|"
    r"instruction[- ]tuning|"
    r"prompt(ing)?"
    r")\b",
    flags=re.IGNORECASE,
)


def add_period(year: pd.Series, transition_year: int = 2023, post_start: int = 2024) -> pd.Series:
    values = np.where(year < transition_year, "pre", np.where(year >= post_start, "post", "transition"))
    return pd.Series(values, index=year.index, dtype="string")


def mark_newcomers(
    authorships: pd.DataFrame,
    *,
    lookback_years: int = 5,
    author_column: str = "author_key",
    venue_column: str = "venue",
    year_column: str = "year",
) -> pd.DataFrame:
    """Mark author appearances with no prior target-venue appearance in a rolling window.

    Papers within the same conference year do not count as prior exposure. This keeps
    prolific first-cycle authors from being classified differently across their papers.
    """
    required = {author_column, venue_column, year_column}
    missing = required - set(authorships.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    result = authorships.copy()
    history_all: dict[str, set[int]] = defaultdict(set)
    history_venue: dict[tuple[str, str], set[int]] = defaultdict(set)

    unique_years = (
        result[[author_column, venue_column, year_column]]
        .drop_duplicates()
        .sort_values([year_column, author_column, venue_column])
    )
    all_flags: dict[tuple[str, int], bool] = {}
    venue_flags: dict[tuple[str, str, int], bool] = {}

    for year, group in unique_years.groupby(year_column, sort=True):
        year = int(year)
        lower = year - lookback_years
        for row in group.itertuples(index=False):
            author = str(getattr(row, author_column))
            venue = str(getattr(row, venue_column))
            prior_all = history_all[author]
            prior_venue = history_venue[(author, venue)]
            all_flags[(author, year)] = not any(lower <= value < year for value in prior_all)
            venue_flags[(author, venue, year)] = not any(
                lower <= value < year for value in prior_venue
            )
        for row in group.itertuples(index=False):
            author = str(getattr(row, author_column))
            venue = str(getattr(row, venue_column))
            history_all[author].add(year)
            history_venue[(author, venue)].add(year)

    result["top4_newcomer_5y"] = [
        all_flags[(str(author), int(year))]
        for author, year in zip(result[author_column], result[year_column])
    ]
    result["venue_newcomer_5y"] = [
        venue_flags[(str(author), str(venue), int(year))]
        for author, venue, year in zip(
            result[author_column], result[venue_column], result[year_column]
        )
    ]
    return result


def hhi(shares_or_counts: Iterable[float]) -> float:
    values = np.asarray(list(shares_or_counts), dtype=float)
    values = values[np.isfinite(values) & (values > 0)]
    if len(values) == 0:
        return float("nan")
    shares = values / values.sum()
    return float(np.square(shares).sum())


def shannon_effective_number(shares_or_counts: Iterable[float]) -> float:
    values = np.asarray(list(shares_or_counts), dtype=float)
    values = values[np.isfinite(values) & (values > 0)]
    if len(values) == 0:
        return float("nan")
    shares = values / values.sum()
    return float(math.exp(-(shares * np.log(shares)).sum()))


def title_is_llm_related(title: str) -> bool:
    return bool(LLM_TITLE_PATTERN.search(str(title)))


def annual_accepted_metrics(
    papers: pd.DataFrame,
    authorships: pd.DataFrame,
    *,
    analysis_start: int,
    analysis_end: int,
) -> pd.DataFrame:
    papers = papers.loc[papers["year"].between(analysis_start, analysis_end)].copy()
    authorships = authorships.loc[
        authorships["year"].between(analysis_start, analysis_end)
    ].copy()
    papers["llm_title_flag"] = papers["title"].map(title_is_llm_related)

    paper_team = (
        authorships.groupby(["venue", "year", "paper_key"], as_index=False)
        .agg(
            team_size=("author_key", "size"),
            any_top4_newcomer=("top4_newcomer_5y", "max"),
            newcomer_author_share=("top4_newcomer_5y", "mean"),
        )
    )
    first_authors = (
        authorships.sort_values(["paper_key", "author_order"])
        .drop_duplicates("paper_key")
        [["paper_key", "top4_newcomer_5y"]]
        .rename(columns={"top4_newcomer_5y": "first_author_newcomer"})
    )
    paper_team = paper_team.merge(first_authors, on="paper_key", how="left", validate="one_to_one")
    paper_team = paper_team.merge(
        papers[["paper_key", "llm_title_flag"]],
        on="paper_key",
        how="left",
        validate="one_to_one",
    )

    author_counts = (
        authorships.groupby(["venue", "year", "author_key"])
        .size()
        .rename("paper_count")
        .reset_index()
    )
    concentration = (
        author_counts.groupby(["venue", "year"])["paper_count"]
        .apply(hhi)
        .rename("author_output_hhi")
        .reset_index()
    )
    unique_authors = (
        authorships.groupby(["venue", "year"])["author_key"]
        .nunique()
        .rename("unique_authors")
        .reset_index()
    )
    summary = (
        paper_team.groupby(["venue", "year"], as_index=False)
        .agg(
            papers=("paper_key", "nunique"),
            mean_team_size=("team_size", "mean"),
            median_team_size=("team_size", "median"),
            papers_with_newcomer_share=("any_top4_newcomer", "mean"),
            newcomer_author_share=("newcomer_author_share", "mean"),
            first_author_newcomer_share=("first_author_newcomer", "mean"),
            llm_title_share=("llm_title_flag", "mean"),
        )
        .merge(unique_authors, on=["venue", "year"], how="left")
        .merge(concentration, on=["venue", "year"], how="left")
    )
    return summary.sort_values(["venue", "year"]).reset_index(drop=True)

