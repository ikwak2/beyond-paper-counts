#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import pandas as pd
import requests

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from top_ai_entry.common import (  # noqa: E402
    author_key,
    inner_text,
    json_dumps,
    load_config,
    sha256_file,
    utc_now_iso,
    write_json,
)


def download_with_retries(url: str, destination: Path, retries: int = 5) -> bool:
    destination.parent.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": "top-ai-entry-research/0.1 (bibliometric research)"}
    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, timeout=90)
        except requests.RequestException:
            if attempt == retries - 1:
                raise
            time.sleep(2**attempt)
            continue
        if response.status_code == 200 and b"<inproceedings" in response.content:
            destination.write_bytes(response.content)
            return True
        if response.status_code == 404:
            return False
        if response.status_code not in {429, 500, 502, 503, 504}:
            response.raise_for_status()
        time.sleep(2**attempt)
    raise RuntimeError(f"Could not download {url}")


def parse_dblp_xml(path: Path, venue: str, expected_year: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    root = ET.parse(path).getroot()
    papers: list[dict[str, Any]] = []
    authorships: list[dict[str, Any]] = []
    for record in root.iter("inproceedings"):
        year_text = inner_text(record.find("year"))
        if not year_text or int(year_text) != expected_year:
            continue
        key = record.attrib.get("key", "")
        title = inner_text(record.find("title"))
        booktitle = inner_text(record.find("booktitle"))
        authors = record.findall("author")
        author_names = [inner_text(item) for item in authors]
        author_pids = [item.attrib.get("pid", "") for item in authors]
        electronic_editions = [inner_text(item) for item in record.findall("ee")]
        paper_key = f"dblp:{key}"
        papers.append(
            {
                "paper_key": paper_key,
                "dblp_key": key,
                "venue": venue,
                "year": expected_year,
                "title": title,
                "booktitle": booktitle,
                "pages": inner_text(record.find("pages")),
                "crossref": inner_text(record.find("crossref")),
                "dblp_url": inner_text(record.find("url")),
                "electronic_editions": json_dumps(electronic_editions),
                "author_names": json_dumps(author_names),
                "author_pids": json_dumps(author_pids),
                "author_count": len(author_names),
            }
        )
        for order, (name, pid) in enumerate(zip(author_names, author_pids), start=1):
            authorships.append(
                {
                    "paper_key": paper_key,
                    "dblp_key": key,
                    "venue": venue,
                    "year": expected_year,
                    "author_order": order,
                    "author_name": name,
                    "author_pid": pid,
                    "author_key": author_key(pid, name),
                    "identity_source": "dblp_pid" if pid else "normalized_name",
                }
            )
    return papers, authorships


def main() -> None:
    parser = argparse.ArgumentParser(description="Download accepted-paper metadata from DBLP.")
    parser.add_argument("--start-year", type=int)
    parser.add_argument("--end-year", type=int)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--delay", type=float, default=0.35)
    args = parser.parse_args()

    config = load_config(PROJECT_ROOT)
    start_year = args.start_year or int(config["history_start_year"])
    end_year = args.end_year or int(config["analysis_end_year"])
    raw_dir = PROJECT_ROOT / "data" / "raw" / "dblp"
    processed_dir = PROJECT_ROOT / "data" / "processed"
    processed_dir.mkdir(parents=True, exist_ok=True)

    all_papers: list[dict[str, Any]] = []
    all_authorships: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []

    for venue, venue_config in config["venues"].items():
        slug = venue_config["dblp_slug"]
        stems = venue_config["dblp_file_stems"]
        for year in range(start_year, end_year + 1):
            destination = raw_dir / venue.lower() / f"{year}.xml"
            source_url = ""
            if not destination.exists() or args.force:
                found = False
                for stem in stems:
                    candidate = f"https://dblp1.uni-trier.de/db/conf/{slug}/{stem}{year}.xml"
                    if download_with_retries(candidate, destination):
                        source_url = candidate
                        found = True
                        break
                if not found:
                    print(f"WARNING no DBLP file found for {venue} {year}", file=sys.stderr)
                    continue
                time.sleep(args.delay)
            else:
                source_url = "cached"

            papers, authorships = parse_dblp_xml(destination, venue, year)
            if not papers:
                print(f"WARNING zero inproceedings records for {venue} {year}", file=sys.stderr)
                continue
            all_papers.extend(papers)
            all_authorships.extend(authorships)
            provenance.append(
                {
                    "venue": venue,
                    "year": year,
                    "source_url": source_url,
                    "local_file": str(destination.relative_to(PROJECT_ROOT)),
                    "sha256": sha256_file(destination),
                    "records": len(papers),
                    "retrieved_at": utc_now_iso(),
                }
            )
            print(f"{venue} {year}: {len(papers):,} accepted papers")

    papers_df = pd.DataFrame(all_papers).drop_duplicates("paper_key")
    authorships_df = pd.DataFrame(all_authorships).drop_duplicates(
        ["paper_key", "author_order"]
    )
    papers_df.to_csv(processed_dir / "accepted_papers_dblp.csv", index=False)
    authorships_df.to_csv(processed_dir / "accepted_authorships_dblp.csv", index=False)
    write_json(
        raw_dir / "provenance.json",
        {
            "created_at": utc_now_iso(),
            "license": "DBLP metadata are released under CC0 1.0",
            "snapshots": provenance,
        },
    )
    print(
        f"Wrote {len(papers_df):,} papers and {len(authorships_df):,} authorships "
        f"to {processed_dir}"
    )


if __name__ == "__main__":
    main()

