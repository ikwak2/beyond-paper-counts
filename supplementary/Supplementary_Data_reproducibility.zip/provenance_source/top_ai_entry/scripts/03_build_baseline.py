#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from top_ai_entry.common import load_config, normalize_author_name  # noqa: E402
from top_ai_entry.metrics import (  # noqa: E402
    add_period,
    annual_accepted_metrics,
    mark_newcomers,
    title_is_llm_related,
)


def markdown_table(frame: pd.DataFrame, digits: int = 3) -> str:
    if frame.empty:
        return "_No records._"
    columns = list(frame.columns)
    rows = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for record in frame.to_dict(orient="records"):
        cells: list[str] = []
        for column in columns:
            value = record[column]
            if isinstance(value, float):
                cells.append("" if pd.isna(value) else f"{value:.{digits}f}")
            else:
                cells.append(str(value))
        rows.append("| " + " | ".join(cells) + " |")
    return "\n".join(rows)


def split_comma_separated(value: object) -> list[str]:
    """Return non-empty values from the ICLR comma-separated string fields."""
    if value is None:
        return []
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, (list, tuple)):
        items = value
    else:
        text = str(value).strip()
        if not text or text.casefold() in {"nan", "none", "null"}:
            return []
        items = text.split(",")
    return [
        text
        for item in items
        if (text := str(item).strip())
        and text.casefold() not in {"nan", "none", "null"}
    ]


def iclr_author_key(
    year: int,
    name: str,
    openreview_author_id: str = "",
) -> tuple[str, str]:
    """Build a stable author key, preferring OpenReview IDs from 2021 onward."""
    author_id = str(openreview_author_id).strip()
    if year >= 2021 and author_id and author_id.casefold() not in {"nan", "none", "null"}:
        return f"openreview:{author_id}", "openreview_id"
    return f"name:{normalize_author_name(name)}", "normalized_name"


def add_newcomer_history_keys(authorships: pd.DataFrame) -> pd.DataFrame:
    """Bridge pre-ID names to a unique later OpenReview ID for newcomer history."""
    result = authorships.copy()
    result["normalized_author_name"] = result["author_name"].map(
        normalize_author_name
    )
    author_ids = result["openreview_author_id"].fillna("").astype(str).str.strip()
    has_id = author_ids.ne("") & ~author_ids.str.casefold().isin(
        {"nan", "none", "null"}
    )
    identified = result.loc[
        has_id & result["normalized_author_name"].ne(""),
        ["normalized_author_name", "openreview_author_id"],
    ].copy()
    id_counts = identified.groupby("normalized_author_name")[
        "openreview_author_id"
    ].nunique()
    unique_names = set(id_counts.loc[id_counts.eq(1)].index)
    ambiguous_names = set(id_counts.loc[id_counts.gt(1)].index)
    name_to_id = (
        identified.loc[identified["normalized_author_name"].isin(unique_names)]
        .drop_duplicates("normalized_author_name")
        .set_index("normalized_author_name")["openreview_author_id"]
    )

    mapped_id = result["normalized_author_name"].map(name_to_id)
    bridged = ~has_id & mapped_id.notna()
    ambiguous_unlinked = (
        ~has_id & result["normalized_author_name"].isin(ambiguous_names)
    )
    result["newcomer_history_key"] = result["author_key"]
    result.loc[bridged, "newcomer_history_key"] = (
        "openreview:" + mapped_id.loc[bridged].astype(str)
    )
    result["newcomer_history_key_source"] = "normalized_name_unlinked"
    result.loc[has_id, "newcomer_history_key_source"] = "direct_openreview_id"
    result.loc[bridged, "newcomer_history_key_source"] = "unique_name_bridge"
    result.loc[
        ambiguous_unlinked,
        "newcomer_history_key_source",
    ] = "ambiguous_name_unlinked"
    return result


def mean_iclr_score(value: object) -> float:
    """Average an ICLR paper's review-score array, ignoring non-numeric entries."""
    if value is None:
        return float("nan")
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, str):
        values: list[object] = [item.strip() for item in value.split(",")]
    elif isinstance(value, (list, tuple)):
        values = list(value)
    else:
        values = [value]
    numeric = pd.to_numeric(pd.Series(values, dtype="object"), errors="coerce").dropna()
    return float(numeric.mean()) if not numeric.empty else float("nan")


def classify_iclr_decision(value: object) -> dict[str, bool]:
    """Classify ICLR decisions while retaining desk rejects outside the main sample."""
    decision = "" if value is None else str(value)
    decision_lower = decision.casefold()
    accepted = (
        any(
            token in decision_lower
            for token in ["accept", "oral", "poster", "spotlight"]
        )
        and "reject" not in decision_lower
    )
    withdrawn = "withdraw" in decision_lower
    desk_rejected = "desk reject" in decision_lower
    return {
        "accepted": accepted,
        "withdrawn": withdrawn,
        "desk_rejected": desk_rejected,
        "valid_decision": bool(decision.strip()) and not withdrawn and not desk_rejected,
    }


def add_within_cycle_score_z(frame: pd.DataFrame) -> pd.DataFrame:
    """Z-standardize paper-mean scores within each year's main decided sample."""
    result = frame.copy()
    raw = result["mean_review_score_raw"]
    reference = raw.where(result["valid_decision"])
    cycle_mean = reference.groupby(result["year"]).transform("mean")
    cycle_sd = reference.groupby(result["year"]).transform(
        lambda values: values.std(ddof=0)
    )
    result["mean_review_score_z"] = (
        (raw - cycle_mean) / cycle_sd.where(cycle_sd.ne(0))
    ).where(result["valid_decision"])
    return result


def analyze_accepted(
    config: dict,
) -> tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    dict,
]:
    processed = PROJECT_ROOT / "data" / "processed"
    papers = pd.read_csv(processed / "accepted_papers_dblp.csv")
    authorships = pd.read_csv(processed / "accepted_authorships_dblp.csv")
    authorships["author_pid"] = authorships["author_pid"].fillna("")
    analysis_start = int(config["analysis_start_year"])
    analysis_end = int(config["analysis_end_year"])
    roster = (
        papers.loc[papers["year"].between(analysis_start, analysis_end)]
        .drop_duplicates("paper_key")
        .copy()
    )
    authorship_paper_keys = set(authorships["paper_key"].astype(str))
    excluded_no_authorship = roster.loc[
        ~roster["paper_key"].astype(str).isin(authorship_paper_keys)
    ].copy()
    marked = mark_newcomers(
        authorships,
        lookback_years=int(config["newcomer_lookback_years"]),
    )
    marked.to_csv(processed / "accepted_authorships_marked.csv", index=False)

    annual = annual_accepted_metrics(
        papers,
        marked,
        analysis_start=analysis_start,
        analysis_end=analysis_end,
    )
    annual["period"] = add_period(
        annual["year"],
        transition_year=int(config["transition_year"]),
        post_start=int(config["clean_post_start_year"]),
    )
    annual.to_csv(processed / "accepted_annual_metrics.csv", index=False)

    comparison = (
        annual.loc[annual["period"].isin(["pre", "post"])]
        .groupby(["venue", "period"], as_index=False)
        .agg(
            yearly_papers=("papers", "mean"),
            mean_team_size=("mean_team_size", "mean"),
            first_author_newcomer_share=("first_author_newcomer_share", "mean"),
            newcomer_author_share=("newcomer_author_share", "mean"),
            llm_title_share=("llm_title_share", "mean"),
        )
    )
    wide = comparison.pivot(index="venue", columns="period")
    changes: list[dict] = []
    for venue in sorted(annual["venue"].unique()):
        row: dict[str, object] = {"venue": venue}
        for metric in [
            "yearly_papers",
            "mean_team_size",
            "first_author_newcomer_share",
            "newcomer_author_share",
            "llm_title_share",
        ]:
            try:
                pre = float(wide.loc[venue, (metric, "pre")])
                post = float(wide.loc[venue, (metric, "post")])
            except KeyError:
                pre = post = float("nan")
            row[f"{metric}_pre"] = pre
            row[f"{metric}_post"] = post
            row[f"{metric}_change"] = post - pre
        changes.append(row)
    changes_df = pd.DataFrame(changes)
    changes_df.to_csv(processed / "accepted_pre_post_descriptive.csv", index=False)

    trend_turn: list[dict] = []
    trend_start = analysis_start
    pivot_year = int(config["transition_year"]) - 1
    post_years = list(
        range(int(config["clean_post_start_year"]), analysis_end + 1)
    )
    for venue in sorted(annual["venue"].unique()):
        venue_frame = annual.loc[annual["venue"].eq(venue)].set_index("year")
        required_years = [trend_start, pivot_year, *post_years]
        if any(year not in venue_frame.index for year in required_years):
            continue
        start_share = float(
            venue_frame.loc[trend_start, "first_author_newcomer_share"]
        )
        pivot_share = float(
            venue_frame.loc[pivot_year, "first_author_newcomer_share"]
        )
        post_mean_share = float(
            venue_frame.loc[post_years, "first_author_newcomer_share"].mean()
        )
        trend_turn.append(
            {
                "venue": venue,
                "start_year": trend_start,
                "pivot_year": pivot_year,
                "post_years": f"{post_years[0]}-{post_years[-1]}",
                "first_author_newcomer_share_start": start_share,
                "first_author_newcomer_share_pivot": pivot_share,
                "first_author_newcomer_share_post_mean": post_mean_share,
                "change_start_to_pivot": pivot_share - start_share,
                "change_pivot_to_post_mean": post_mean_share - pivot_share,
            }
        )
    trend_turn_df = pd.DataFrame(trend_turn)
    trend_turn_df.to_csv(
        processed / "accepted_newcomer_trend_turn.csv", index=False
    )

    post_only_year = int(config["clean_post_start_year"])
    post_2024_sensitivity: list[dict] = []
    for venue in sorted(annual["venue"].unique()):
        venue_frame = annual.loc[annual["venue"].eq(venue)].set_index("year")
        if pivot_year not in venue_frame.index or post_only_year not in venue_frame.index:
            continue
        pivot_share = float(
            venue_frame.loc[pivot_year, "first_author_newcomer_share"]
        )
        post_mean_share = float(
            venue_frame.loc[post_years, "first_author_newcomer_share"].mean()
        )
        post_only_share = float(
            venue_frame.loc[post_only_year, "first_author_newcomer_share"]
        )
        post_2024_sensitivity.append(
            {
                "venue": venue,
                "pivot_year": pivot_year,
                "first_author_newcomer_share_pivot": pivot_share,
                "post_mean_years": f"{post_years[0]}-{post_years[-1]}",
                "first_author_newcomer_share_post_mean": post_mean_share,
                "change_pivot_to_post_mean": post_mean_share - pivot_share,
                "post_only_year": post_only_year,
                "first_author_newcomer_share_post_only": post_only_share,
                "change_pivot_to_post_only": post_only_share - pivot_share,
            }
        )
    post_2024_sensitivity_df = pd.DataFrame(post_2024_sensitivity)
    post_2024_sensitivity_df.to_csv(
        processed / "accepted_post_2024_only_sensitivity.csv", index=False
    )

    roster_counts = (
        roster.groupby(["venue", "year"])["paper_key"].nunique().unstack("year")
    )
    coverage_benchmarks = config.get("official_proceedings_benchmarks", {})
    roster_growth_audit: list[dict] = []
    for venue in sorted(roster_counts.index):
        papers_2024 = int(roster_counts.loc[venue, post_only_year])
        papers_2025 = int(roster_counts.loc[venue, analysis_end])
        benchmark_2024 = coverage_benchmarks.get(venue, {}).get(
            str(post_only_year), {}
        )
        benchmark_2025 = coverage_benchmarks.get(venue, {}).get(
            str(analysis_end), {}
        )
        official_2024_min = benchmark_2024.get("combined_proceedings_min")
        official_2025_min = benchmark_2025.get("combined_proceedings_min")
        official_2024_min_value = (
            int(official_2024_min)
            if official_2024_min is not None
            else float("nan")
        )
        official_2025_min_value = (
            int(official_2025_min)
            if official_2025_min is not None
            else float("nan")
        )
        roster_growth_audit.append(
            {
                "venue": venue,
                "papers_2024": papers_2024,
                "papers_2025": papers_2025,
                "growth_rate_2024_2025": papers_2025 / papers_2024 - 1,
                "official_2024_proceedings_min": official_2024_min,
                "dblp_shortfall_vs_official_2024_min": (
                    official_2024_min_value - papers_2024
                    if official_2024_min is not None
                    else float("nan")
                ),
                "dblp_coverage_vs_official_2024_min": (
                    papers_2024 / official_2024_min_value
                    if official_2024_min is not None
                    else float("nan")
                ),
                "official_2025_main_track": benchmark_2025.get("main_track"),
                "official_2025_datasets_benchmarks_track": benchmark_2025.get(
                    "datasets_benchmarks_track"
                ),
                "official_2025_position_paper_track": benchmark_2025.get(
                    "position_paper_track"
                ),
                "official_2025_proceedings_min": official_2025_min,
                "dblp_shortfall_vs_official_2025_min": (
                    official_2025_min_value - papers_2025
                    if official_2025_min is not None
                    else float("nan")
                ),
                "dblp_coverage_vs_official_2025_min": (
                    papers_2025 / official_2025_min_value
                    if official_2025_min is not None
                    else float("nan")
                ),
            }
        )
    roster_growth_audit_df = pd.DataFrame(roster_growth_audit)
    roster_growth_audit_df.to_csv(
        processed / "accepted_roster_2025_coverage_audit.csv", index=False
    )

    recent_window: list[dict] = []
    recent_start = 2022
    recent_end = analysis_end
    for venue in sorted(annual["venue"].unique()):
        venue_frame = annual.loc[annual["venue"].eq(venue)].set_index("year")
        if recent_start not in venue_frame.index or recent_end not in venue_frame.index:
            continue
        start = venue_frame.loc[recent_start]
        end = venue_frame.loc[recent_end]
        recent_window.append(
            {
                "venue": venue,
                "start_year": recent_start,
                "end_year": recent_end,
                "papers_start": int(start["papers"]),
                "papers_end": int(end["papers"]),
                "papers_change": int(end["papers"] - start["papers"]),
                "first_author_newcomer_share_start": float(
                    start["first_author_newcomer_share"]
                ),
                "first_author_newcomer_share_end": float(
                    end["first_author_newcomer_share"]
                ),
                "first_author_newcomer_share_change": float(
                    end["first_author_newcomer_share"]
                    - start["first_author_newcomer_share"]
                ),
                "newcomer_author_share_start": float(start["newcomer_author_share"]),
                "newcomer_author_share_end": float(end["newcomer_author_share"]),
                "newcomer_author_share_change": float(
                    end["newcomer_author_share"] - start["newcomer_author_share"]
                ),
                "mean_team_size_start": float(start["mean_team_size"]),
                "mean_team_size_end": float(end["mean_team_size"]),
                "mean_team_size_change": float(
                    end["mean_team_size"] - start["mean_team_size"]
                ),
            }
        )
    recent_window_df = pd.DataFrame(recent_window)
    recent_window_df.to_csv(
        processed / "accepted_2022_2025_descriptive.csv", index=False
    )
    excluded_by_venue_year = [
        {
            "venue": str(row.venue),
            "year": int(row.year),
            "papers": int(row.papers),
        }
        for row in excluded_no_authorship.groupby(
            ["venue", "year"], as_index=False
        )
        .size()
        .rename(columns={"size": "papers"})
        .sort_values(["venue", "year"])
        .itertuples(index=False)
    ]
    roster_papers = int(roster["paper_key"].nunique())
    analyzable_papers = int(annual["papers"].sum())
    accepted_audit = {
        "analysis_years": [analysis_start, analysis_end],
        "accepted_paper_roster": roster_papers,
        "authorship_analyzable_papers": analyzable_papers,
        "excluded_no_authorship": len(excluded_no_authorship),
        "excluded_no_authorship_by_venue_year": excluded_by_venue_year,
        "roster_minus_analyzable": roster_papers - analyzable_papers,
        "official_proceedings_benchmarks": config.get(
            "official_proceedings_benchmarks", {}
        ),
        "coverage_warning": (
            "The live DBLP NeurIPS 2025 roster contains 4,573 records versus an "
            "official minimum proceedings benchmark of 5,493. Treat NeurIPS 2025 "
            "as coverage-incomplete and report the post=2024-only sensitivity."
        ),
        "warning": (
            "Proceedings-paper counts come from the DBLP roster, while team and "
            "newcomer metrics require at least one authorship row. Records without "
            "authorships remain in the roster audit but are excluded from the "
            "authorship-analyzable annual panel."
        ),
    }
    return (
        annual,
        changes_df,
        trend_turn_df,
        post_2024_sensitivity_df,
        recent_window_df,
        roster_growth_audit_df,
        accepted_audit,
    )


def analyze_iclr(config: dict, version: str) -> tuple[pd.DataFrame, dict]:
    raw_path = PROJECT_ROOT / "data" / "raw" / "iclr" / f"iclr{version}.parquet"
    frame = pd.read_parquet(raw_path)
    lower_names = {str(column).lower(): column for column in frame.columns}

    def column(*candidates: str) -> str:
        for candidate in candidates:
            if candidate.lower() in lower_names:
                return lower_names[candidate.lower()]
        raise KeyError(f"None of {candidates} found. Available columns: {list(frame.columns)}")

    year_col = column("year")
    title_col = column("title")
    decision_col = column("decision")
    id_col = column("id", "openreview_id", "forum")
    authors_col = column("authors")
    author_ids_col = lower_names.get("author_ids")
    scores_col = lower_names.get("scores")

    rows: list[dict] = []
    author_rows: list[dict] = []
    author_id_length_mismatches = 0
    for record in frame.to_dict(orient="records"):
        year = int(record[year_col])
        paper_key = f"openreview:{record[id_col]}"
        decision = str(record.get(decision_col, ""))
        decision_flags = classify_iclr_decision(decision)
        authors_value = split_comma_separated(record.get(authors_col))
        author_ids_value = (
            split_comma_separated(record.get(author_ids_col))
            if author_ids_col is not None
            else []
        )
        if author_ids_value and len(author_ids_value) != len(authors_value):
            author_id_length_mismatches += 1
        title = str(record.get(title_col, ""))
        mean_review_score_raw = (
            mean_iclr_score(record.get(scores_col))
            if scores_col is not None
            else float("nan")
        )
        rows.append(
            {
                "paper_key": paper_key,
                "venue": "ICLR",
                "year": year,
                "title": title,
                "decision": decision,
                **decision_flags,
                "team_size": len(authors_value),
                "mean_review_score_raw": mean_review_score_raw,
                "llm_title_flag": title_is_llm_related(title),
            }
        )
        for order, name in enumerate(authors_value, start=1):
            author_id = (
                author_ids_value[order - 1]
                if order <= len(author_ids_value)
                else ""
            )
            key, key_source = iclr_author_key(year, name, author_id)
            author_rows.append(
                {
                    "paper_key": paper_key,
                    "venue": "ICLR",
                    "year": year,
                    "author_order": order,
                    "author_name": str(name),
                    "openreview_author_id": author_id,
                    "author_key": key,
                    "author_key_source": key_source,
                }
            )

    papers = add_within_cycle_score_z(pd.DataFrame(rows))
    authorships = add_newcomer_history_keys(pd.DataFrame(author_rows))
    id_assisted_marked = mark_newcomers(
        authorships,
        lookback_years=int(config["newcomer_lookback_years"]),
        author_column="newcomer_history_key",
    )
    authorships = mark_newcomers(
        authorships,
        lookback_years=int(config["newcomer_lookback_years"]),
        author_column="normalized_author_name",
    )
    authorships["top4_newcomer_5y_name_only"] = authorships["top4_newcomer_5y"]
    authorships["venue_newcomer_5y_name_only"] = authorships[
        "venue_newcomer_5y"
    ]
    authorships["top4_newcomer_5y_id_assisted"] = id_assisted_marked[
        "top4_newcomer_5y"
    ]
    authorships["venue_newcomer_5y_id_assisted"] = id_assisted_marked[
        "venue_newcomer_5y"
    ]
    first = (
        authorships.sort_values(["paper_key", "author_order"])
        .drop_duplicates("paper_key")
        [
            [
                "paper_key",
                "top4_newcomer_5y",
                "top4_newcomer_5y_name_only",
                "top4_newcomer_5y_id_assisted",
            ]
        ]
        .rename(
            columns={
                "top4_newcomer_5y": "first_author_observed_newcomer",
                "top4_newcomer_5y_name_only": (
                    "first_author_observed_newcomer_name_only"
                ),
                "top4_newcomer_5y_id_assisted": (
                    "first_author_observed_newcomer_id_assisted"
                ),
            }
        )
    )
    papers = papers.merge(first, on="paper_key", how="left", validate="one_to_one")
    analysis = papers.loc[
        papers["year"].between(
            int(config["analysis_start_year"]), int(config["analysis_end_year"])
        )
    ].copy()
    decided = analysis.loc[analysis["valid_decision"]].copy()
    decided["accepted_newcomer"] = (
        decided["accepted"]
        & decided["first_author_observed_newcomer"].fillna(False).astype(bool)
    )
    decided["accepted_newcomer_name_only"] = (
        decided["accepted"]
        & decided["first_author_observed_newcomer_name_only"]
        .fillna(False)
        .astype(bool)
    )
    decided["accepted_newcomer_id_assisted"] = (
        decided["accepted"]
        & decided["first_author_observed_newcomer_id_assisted"]
        .fillna(False)
        .astype(bool)
    )
    summary = (
        decided.groupby("year", as_index=False)
        .agg(
            submissions_with_decision=("paper_key", "nunique"),
            accepted=("accepted", "sum"),
            acceptance_rate=("accepted", "mean"),
            mean_team_size=("team_size", "mean"),
            mean_review_score_raw=("mean_review_score_raw", "mean"),
            mean_review_score_z=("mean_review_score_z", "mean"),
            first_author_observed_newcomer_count=(
                "first_author_observed_newcomer",
                "sum",
            ),
            first_author_observed_newcomer_share=(
                "first_author_observed_newcomer",
                "mean",
            ),
            accepted_newcomer_count=("accepted_newcomer", "sum"),
            first_author_observed_newcomer_name_only_count=(
                "first_author_observed_newcomer_name_only",
                "sum",
            ),
            first_author_observed_newcomer_name_only_share=(
                "first_author_observed_newcomer_name_only",
                "mean",
            ),
            accepted_newcomer_name_only_count=(
                "accepted_newcomer_name_only",
                "sum",
            ),
            first_author_observed_newcomer_id_assisted_count=(
                "first_author_observed_newcomer_id_assisted",
                "sum",
            ),
            first_author_observed_newcomer_id_assisted_share=(
                "first_author_observed_newcomer_id_assisted",
                "mean",
            ),
            accepted_newcomer_id_assisted_count=(
                "accepted_newcomer_id_assisted",
                "sum",
            ),
            llm_title_share=("llm_title_flag", "mean"),
        )
    )
    newcomer_acceptance = (
        decided.groupby(["year", "first_author_observed_newcomer"])["accepted"]
        .mean()
        .unstack()
        .rename(columns={False: "returning_acceptance_rate", True: "newcomer_acceptance_rate"})
        .reset_index()
    )
    summary = summary.merge(newcomer_acceptance, on="year", how="left")
    summary["newcomer_acceptance_gap"] = (
        summary["newcomer_acceptance_rate"] - summary["returning_acceptance_rate"]
    )
    newcomer_score = (
        decided.groupby(["year", "first_author_observed_newcomer"])[
            "mean_review_score_z"
        ]
        .mean()
        .unstack()
        .rename(
            columns={
                False: "returning_mean_review_score_z",
                True: "newcomer_mean_review_score_z",
            }
        )
    )
    for score_column in [
        "returning_mean_review_score_z",
        "newcomer_mean_review_score_z",
    ]:
        if score_column not in newcomer_score:
            newcomer_score[score_column] = float("nan")
    summary = summary.merge(newcomer_score.reset_index(), on="year", how="left")
    summary["newcomer_review_score_z_gap"] = (
        summary["newcomer_mean_review_score_z"]
        - summary["returning_mean_review_score_z"]
    )
    for count_column in [
        "first_author_observed_newcomer_count",
        "accepted_newcomer_count",
        "first_author_observed_newcomer_name_only_count",
        "accepted_newcomer_name_only_count",
        "first_author_observed_newcomer_id_assisted_count",
        "accepted_newcomer_id_assisted_count",
    ]:
        summary[count_column] = summary[count_column].fillna(0).astype(int)
    summary["id_assisted_minus_name_only_newcomer_share"] = (
        summary["first_author_observed_newcomer_id_assisted_share"]
        - summary["first_author_observed_newcomer_name_only_share"]
    )
    summary["period"] = add_period(
        summary["year"],
        transition_year=int(config["transition_year"]),
        post_start=int(config["clean_post_start_year"]),
    )

    processed = PROJECT_ROOT / "data" / "processed"
    papers.to_csv(processed / "iclr_submissions_normalized.csv", index=False)
    authorships.to_csv(processed / "iclr_submission_authorships.csv", index=False)
    summary.to_csv(processed / "iclr_funnel_annual.csv", index=False)
    lookback_years = int(config["newcomer_lookback_years"])
    history_start_year = int(papers["year"].min())
    first_full_lookback_year = history_start_year + lookback_years
    left_censored_years = sorted(
        int(year)
        for year in analysis["year"].unique()
        if int(year) < first_full_lookback_year
    )
    desk_rejected_by_year = {
        str(int(year)): int(count)
        for year, count in analysis.groupby("year", sort=True)["desk_rejected"].sum().items()
    }
    id_used_share_by_year = {
        str(int(year)): float(share)
        for year, share in authorships.assign(
            id_used=authorships["author_key_source"].eq("openreview_id")
        )
        .groupby("year", sort=True)["id_used"]
        .mean()
        .items()
    }
    name_rows = authorships.loc[
        authorships["author_key_source"].eq("normalized_name")
    ].copy()
    name_bridge_share_by_year = {
        str(int(year)): float(share)
        for year, share in name_rows.assign(
            bridged=name_rows["newcomer_history_key_source"].eq(
                "unique_name_bridge"
            )
        )
        .groupby("year", sort=True)["bridged"]
        .mean()
        .items()
    }
    newcomer_shares = decided.groupby("year", sort=True).agg(
        name_only=("first_author_observed_newcomer_name_only", "mean"),
        id_assisted=("first_author_observed_newcomer_id_assisted", "mean"),
    )
    newcomer_share_by_year = {
        str(int(year)): {
            "name_only_primary": float(row.name_only),
            "id_assisted_sensitivity": float(row.id_assisted),
        }
        for year, row in newcomer_shares.iterrows()
    }
    share_change_2020_to_2021 = {
        "name_only_primary": float(
            newcomer_shares.loc[2021, "name_only"]
            - newcomer_shares.loc[2020, "name_only"]
        ),
        "id_assisted_sensitivity": float(
            newcomer_shares.loc[2021, "id_assisted"]
            - newcomer_shares.loc[2020, "id_assisted"]
        ),
    }
    bridged_name_rows = int(
        name_rows["newcomer_history_key_source"].eq("unique_name_bridge").sum()
    )
    ambiguous_name_rows = int(
        name_rows["newcomer_history_key_source"]
        .eq("ambiguous_name_unlinked")
        .sum()
    )
    audit = {
        "source_rows": len(frame),
        "normalized_papers": len(papers),
        "analysis_papers": len(analysis),
        "valid_decisions": int(analysis["valid_decision"].sum()),
        "withdrawn": int(analysis["withdrawn"].sum()),
        "desk_rejected_total": int(analysis["desk_rejected"].sum()),
        "desk_rejected_by_year": desk_rejected_by_year,
        "history_start_year": history_start_year,
        "newcomer_lookback_years": lookback_years,
        "first_full_lookback_year": first_full_lookback_year,
        "left_censored_analysis_years": left_censored_years,
        "openreview_id_author_keys": int(
            authorships["author_key_source"].eq("openreview_id").sum()
        ),
        "normalized_name_author_keys": int(
            authorships["author_key_source"].eq("normalized_name").sum()
        ),
        "id_used_share_by_year": id_used_share_by_year,
        "normalized_name_rows_without_direct_id": len(name_rows),
        "unique_name_bridge_rows": bridged_name_rows,
        "name_to_unique_id_bridge_share": (
            bridged_name_rows / len(name_rows) if len(name_rows) else None
        ),
        "name_bridge_share_by_year": name_bridge_share_by_year,
        "ambiguous_normalized_names": int(
            authorships.loc[
                authorships["newcomer_history_key_source"].eq(
                    "ambiguous_name_unlinked"
                ),
                "normalized_author_name",
            ].nunique()
        ),
        "ambiguous_name_rows_unlinked": ambiguous_name_rows,
        "first_author_newcomer_share_by_year": newcomer_share_by_year,
        "first_author_newcomer_share_change_2020_to_2021": (
            share_change_2020_to_2021
        ),
        "newcomer_identity_strategy": (
            "Primary: normalized-name keys in every year for temporal consistency. "
            "Sensitivity: OpenReview IDs from 2021 onward with exact normalized-name "
            "bridges only when one name maps to one ID."
        ),
        "author_id_length_mismatches": author_id_length_mismatches,
        "review_score_standardization": (
            "Paper-level mean review scores are z-standardized within ICLR cycle "
            "using main valid decisions with observed scores (population SD, ddof=0)."
        ),
        "review_score_warning": (
            "Review scales, rubrics, and reviewer composition can change by cycle. "
            "Do not interpret trends in mean_review_score_raw as substantive score "
            "changes across years; use within-cycle mean_review_score_z for group "
            "contrasts, which also remain descriptive."
        ),
        "columns": [str(value) for value in frame.columns],
        "warning": (
            "The public ICLR history starts in "
            f"{history_start_year}; with a {lookback_years}-year lookback, "
            f"{left_censored_years} are left-censored. Early observed-newcomer "
            "levels, especially 2018, are mechanically inflated and are not true "
            "career-first entry rates. From 2021 onward, OpenReview author IDs are "
            "used when available. Earlier name rows are bridged only when a normalized "
            "name maps to exactly one later ID; ambiguous names remain unlinked. "
            "Because incomplete bridges can create false newcomers at the 2021 ID "
            "boundary, the temporally consistent name-only measure is primary and "
            "the ID-assisted measure is sensitivity-only. Both strategies can merge "
            "or split authors, so all observed-newcomer estimates "
            "remain descriptive until identity linkage is audited. Desk-rejected "
            "submissions are retained and flagged but excluded from valid_decision."
        ),
    }
    return summary, audit



def build_iclr_full_lookback_focus(iclr: pd.DataFrame, first_full_year: int) -> pd.DataFrame:
    focus = iclr.loc[iclr["year"].ge(first_full_year)].copy()
    columns = [
        "year",
        "submissions_with_decision",
        "accepted",
        "first_author_observed_newcomer_count",
        "first_author_observed_newcomer_share",
        "accepted_newcomer_count",
        "newcomer_acceptance_rate",
        "returning_acceptance_rate",
        "newcomer_acceptance_gap",
        "newcomer_review_score_z_gap",
        "mean_team_size",
        "llm_title_share",
    ]
    focus = focus[columns].rename(
        columns={
            "year": "cycle",
            "submissions_with_decision": "valid_decisions",
            "first_author_observed_newcomer_count": "newcomer_submissions",
            "first_author_observed_newcomer_share": "newcomer_submission_share",
            "accepted_newcomer_count": "newcomer_accepts",
            "newcomer_review_score_z_gap": "review_score_z_gap",
        }
    )
    if focus.empty:
        return focus
    baseline_acceptance_gap = abs(float(focus.iloc[0]["newcomer_acceptance_gap"]))
    baseline_score_gap = abs(float(focus.iloc[0]["review_score_z_gap"]))
    if baseline_acceptance_gap:
        focus["acceptance_penalty_reduction_vs_first"] = (
            1 - focus["newcomer_acceptance_gap"].abs() / baseline_acceptance_gap
        )
    else:
        focus["acceptance_penalty_reduction_vs_first"] = float("nan")
    if baseline_score_gap:
        focus["score_penalty_reduction_vs_first"] = (
            1 - focus["review_score_z_gap"].abs() / baseline_score_gap
        )
    else:
        focus["score_penalty_reduction_vs_first"] = float("nan")
    return focus.reset_index(drop=True)


def coerce_bool_series(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False).astype(bool)
    return series.fillna(False).map(
        lambda value: str(value).strip().casefold() in {"true", "1", "yes"}
    )


def build_iclr_withdrawal_tables(
    papers: pd.DataFrame,
    main_summary: pd.DataFrame,
    first_full_year: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    frame = papers.copy()
    for column in [
        "accepted",
        "withdrawn",
        "desk_rejected",
        "valid_decision",
        "first_author_observed_newcomer",
    ]:
        frame[column] = coerce_bool_series(frame[column])
    frame["newcomer"] = frame["first_author_observed_newcomer"]

    withdrawal_rows: list[dict] = []
    for year, group in frame.groupby("year", sort=True):
        withdrawn = group["withdrawn"]
        nonwithdrawn = ~withdrawn
        newcomer_withdrawn = group.loc[withdrawn, "newcomer"].mean()
        newcomer_nonwithdrawn = group.loc[nonwithdrawn, "newcomer"].mean()
        withdrawal_rows.append(
            {
                "year": int(year),
                "total_submissions": int(len(group)),
                "valid_decisions": int(group["valid_decision"].sum()),
                "withdrawn": int(withdrawn.sum()),
                "desk_rejected": int(group["desk_rejected"].sum()),
                "withdrawal_rate": float(withdrawn.mean()),
                "newcomer_share_withdrawn": float(newcomer_withdrawn),
                "newcomer_share_nonwithdrawn": float(newcomer_nonwithdrawn),
                "withdrawal_newcomer_excess_vs_nonwithdrawn": float(
                    newcomer_withdrawn - newcomer_nonwithdrawn
                ),
            }
        )
    withdrawal_annual = pd.DataFrame(withdrawal_rows)

    # Robustness sample: keep main desk-reject exclusion, add withdrawals as
    # non-acceptances. Score gaps use all observed review scores in this sample.
    itt = frame.loc[frame["valid_decision"] | frame["withdrawn"]].copy()
    raw = itt["mean_review_score_raw"]
    cycle_mean = raw.groupby(itt["year"]).transform("mean")
    cycle_sd = raw.groupby(itt["year"]).transform(lambda values: values.std(ddof=0))
    itt["mean_review_score_z_with_withdrawals"] = (
        (raw - cycle_mean) / cycle_sd.where(cycle_sd.ne(0))
    )
    counts = (
        itt.groupby("year", as_index=False)
        .agg(
            itt_submissions=("paper_key", "nunique"),
            valid_decisions=("valid_decision", "sum"),
            withdrawals=("withdrawn", "sum"),
            accepted=("accepted", "sum"),
            newcomer_submissions=("newcomer", "sum"),
        )
    )
    acceptance = (
        itt.groupby(["year", "newcomer"])["accepted"]
        .mean()
        .unstack()
        .rename(
            columns={
                False: "itt_returning_acceptance_rate",
                True: "itt_newcomer_acceptance_rate",
            }
        )
    )
    score = (
        itt.groupby(["year", "newcomer"])["mean_review_score_z_with_withdrawals"]
        .mean()
        .unstack()
        .rename(
            columns={
                False: "itt_returning_review_score_z",
                True: "itt_newcomer_review_score_z",
            }
        )
    )
    itt_summary = counts.merge(acceptance.reset_index(), on="year", how="left")
    itt_summary = itt_summary.merge(score.reset_index(), on="year", how="left")
    itt_summary["itt_acceptance_gap"] = (
        itt_summary["itt_newcomer_acceptance_rate"]
        - itt_summary["itt_returning_acceptance_rate"]
    )
    itt_summary["itt_review_score_z_gap"] = (
        itt_summary["itt_newcomer_review_score_z"]
        - itt_summary["itt_returning_review_score_z"]
    )
    valid_gaps = main_summary[
        ["year", "newcomer_acceptance_gap", "newcomer_review_score_z_gap"]
    ].rename(
        columns={
            "newcomer_acceptance_gap": "valid_acceptance_gap",
            "newcomer_review_score_z_gap": "valid_review_score_z_gap",
        }
    )
    itt_summary = itt_summary.merge(valid_gaps, on="year", how="left")
    withdrawal_for_merge = withdrawal_annual[
        [
            "year",
            "total_submissions",
            "withdrawal_rate",
            "withdrawal_newcomer_excess_vs_nonwithdrawn",
        ]
    ]
    itt_summary = itt_summary.merge(withdrawal_for_merge, on="year", how="left")
    itt_focus = itt_summary.loc[itt_summary["year"].ge(first_full_year)].copy()
    if not itt_focus.empty:
        baseline = abs(float(itt_focus.iloc[0]["itt_review_score_z_gap"]))
        if baseline:
            itt_focus["itt_score_penalty_reduction_vs_first"] = (
                1 - itt_focus["itt_review_score_z_gap"].abs() / baseline
            )
        else:
            itt_focus["itt_score_penalty_reduction_vs_first"] = float("nan")
    itt_focus = itt_focus.rename(columns={"year": "cycle"}).reset_index(drop=True)
    focus_columns = [
        "cycle",
        "total_submissions",
        "itt_submissions",
        "valid_decisions",
        "withdrawals",
        "withdrawal_rate",
        "withdrawal_newcomer_excess_vs_nonwithdrawn",
        "valid_acceptance_gap",
        "itt_acceptance_gap",
        "valid_review_score_z_gap",
        "itt_review_score_z_gap",
        "itt_score_penalty_reduction_vs_first",
    ]
    return withdrawal_annual, itt_focus[focus_columns]


def make_plots(accepted: pd.DataFrame, iclr: pd.DataFrame) -> None:
    output_dir = PROJECT_ROOT / "outputs" / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(9, 5))
    for venue, group in accepted.groupby("venue"):
        ax.plot(group["year"], group["papers"], marker="o", label=venue)
    ax.axvline(2023, color="black", linestyle="--", alpha=0.5)
    ax.set(title="Accepted papers by venue and year", xlabel="Conference year", ylabel="Papers")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "accepted_papers_by_year.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    for venue, group in accepted.groupby("venue"):
        ax.plot(
            group["year"],
            group["first_author_newcomer_share"],
            marker="o",
            label=venue,
        )
    ax.axvline(2023, color="black", linestyle="--", alpha=0.5)
    ax.set(
        title="Five-year top-four newcomer share among first authors",
        xlabel="Conference year",
        ylabel="Share",
        ylim=(0, 1),
    )
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "accepted_first_author_newcomer_share.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(iclr["year"], iclr["acceptance_rate"], marker="o", label="All decided")
    ax.plot(
        iclr["year"],
        iclr["newcomer_acceptance_rate"],
        marker="o",
        label="Observed first-time submitter",
    )
    ax.plot(
        iclr["year"],
        iclr["returning_acceptance_rate"],
        marker="o",
        label="Returning submitter",
    )
    ax.axvline(2023, color="black", linestyle="--", alpha=0.5)
    ax.set(
        title="ICLR acceptance rates: observed newcomers vs returning authors",
        xlabel="Conference year",
        ylabel="Acceptance rate",
        ylim=(0, 1),
    )
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "iclr_acceptance_funnel.png", dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build initial descriptive panels and figures.")
    parser.add_argument("--iclr-version", default="25v2")
    args = parser.parse_args()

    config = load_config(PROJECT_ROOT)
    (
        accepted,
        changes,
        trend_turn,
        post_2024_sensitivity,
        recent_accepted,
        roster_growth_audit,
        accepted_audit,
    ) = analyze_accepted(config)
    iclr, audit = analyze_iclr(config, args.iclr_version)
    iclr_focus = build_iclr_full_lookback_focus(
        iclr, int(audit["first_full_lookback_year"])
    )
    processed_dir = PROJECT_ROOT / "data" / "processed"
    iclr_focus.to_csv(processed_dir / "iclr_2022_2025_focus.csv", index=False)
    iclr_papers = pd.read_csv(processed_dir / "iclr_submissions_normalized.csv")
    withdrawal_annual, withdrawal_itt = build_iclr_withdrawal_tables(
        iclr_papers, iclr, int(audit["first_full_lookback_year"])
    )
    withdrawal_annual.to_csv(
        processed_dir / "iclr_withdrawal_audit_annual.csv", index=False
    )
    withdrawal_itt.to_csv(
        processed_dir / "iclr_withdrawal_itt_2022_2025.csv", index=False
    )
    make_plots(accepted, iclr)

    output_dir = PROJECT_ROOT / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    desk_rejected_by_year = ", ".join(
        f"{year}: {count}" for year, count in audit["desk_rejected_by_year"].items()
    )
    identity_change = audit["first_author_newcomer_share_change_2020_to_2021"]
    name_only_change_pp = 100 * identity_change["name_only_primary"]
    id_assisted_change_pp = 100 * identity_change["id_assisted_sensitivity"]
    no_authorship_by_cell = ", ".join(
        f"{row['venue']} {row['year']}: {row['papers']}"
        for row in accepted_audit["excluded_no_authorship_by_venue_year"]
    )
    first_full_year = int(audit["first_full_lookback_year"])
    accepted_report = accepted.drop(columns=["author_output_hhi"], errors="ignore")
    focus_start = iclr_focus.iloc[0]
    focus_end = iclr_focus.iloc[-1]
    itt_start = withdrawal_itt.iloc[0]
    itt_end = withdrawal_itt.iloc[-1]
    score_reduction_pct = 100 * float(
        focus_end["score_penalty_reduction_vs_first"]
    )
    acceptance_reduction_pct = 100 * float(
        focus_end["acceptance_penalty_reduction_vs_first"]
    )
    itt_score_reduction_pct = 100 * float(
        itt_end["itt_score_penalty_reduction_vs_first"]
    )
    withdrawal_report = withdrawal_annual.loc[
        withdrawal_annual["year"].between(2018, int(config["analysis_end_year"]))
    ].copy()
    neurips_coverage = roster_growth_audit.loc[
        roster_growth_audit["venue"].eq("NeurIPS")
    ].iloc[0]
    coverage_report = roster_growth_audit[
        [
            "venue",
            "papers_2024",
            "papers_2025",
            "growth_rate_2024_2025",
            "official_2024_proceedings_min",
            "dblp_coverage_vs_official_2024_min",
            "official_2025_proceedings_min",
            "dblp_coverage_vs_official_2025_min",
        ]
    ]
    report = f"""# Initial feasibility results

Generated from public DBLP proceedings records and the public ICLR submissions
dataset. These are descriptive data checks, not estimates of the causal effect of LLMs.

## Coverage

- DBLP proceedings roster: {accepted_audit['accepted_paper_roster']:,} papers;
  authorship-analyzable panel: {accepted_audit['authorship_analyzable_papers']:,}
  papers across {accepted['venue'].nunique()} venues,
  {accepted['year'].min()}–{accepted['year'].max()}.
- The accepted-paper newcomer metric has 2013–2017 DBLP history available, so the
  2018 accepted-panel five-year top-four lookback is not mechanically left-censored
  under the current definition. It is still an accepted-paper-only panel and cannot
  identify rejected submissions.
- Records excluded from author/team/newcomer metrics because DBLP supplied no
  authorship row: {accepted_audit['excluded_no_authorship']:,}
  ({no_authorship_by_cell}). They remain counted in the roster audit.
- ICLR source rows: {audit['source_rows']:,}; valid decisions in the analysis window:
  {audit['valid_decisions']:,}.
- The ICLR public submission archive begins in {audit['history_start_year']}. With a
  {audit['newcomer_lookback_years']}-year rolling submission-history definition, the
  full-lookback ICLR window starts in {first_full_year}. This left-censoring warning
  applies to the ICLR submission funnel only, not to the DBLP accepted panel.
- Desk-rejected submissions are retained with a flag but excluded from the main
  valid-decision and ITT robustness denominators: {audit['desk_rejected_total']:,}
  total ({desk_rejected_by_year}). The original decision labels, including 2018's
  `Invite to Workshop Track`, remain unchanged.
- The name-only definition is the pilot's primary observed-newcomer measure because
  it is consistent across years. The ID-assisted bridge links
  {audit['name_to_unique_id_bridge_share']:.1%} of rows without direct IDs and is
  sensitivity-only. From 2020 to 2021, newcomer share changes by
  {name_only_change_pp:+.1f} pp under the primary definition versus
  {id_assisted_change_pp:+.1f} pp under the ID-assisted sensitivity definition.

## Headline 1: the proceedings newcomer-share decline stalls around 2022

Because the DBLP proceedings panel includes 2013–2017 history, the 2018 panel
five-year top-four newcomer shares are not a left-censoring artifact. However, a
2018–2022 pre-period average versus 2024–2025 post-period average mixes two different
patterns. Most of the share decline occurs inside 2018–2022. Relative to 2022,
the 2024–2025 mean is slightly higher in ICLR, ICML, and NeurIPS; AAAI is the
exception and continues to decline.

{markdown_table(trend_turn)}

### 2025 coverage audit and 2024-only post sensitivity

The 2025 proceedings roster is not equally complete across venues. The live DBLP
NeurIPS 2025 XML checked on 2026-07-31 contains
{int(neurips_coverage['papers_2025']):,} records. Official NeurIPS sources report
[5,290 main-track papers](https://blog.neurips.cc/2025/09/30/reflections-on-the-2025-review-process-from-the-program-committee-chairs/),
[163 Datasets & Benchmarks papers](https://neurips.cc/Conferences/2025/DatasetsBenchmarks/AcceptedPapers),
and [40 Position papers](https://blog.neurips.cc/2025/10/02/reflecting-on-the-inaugural-neurips-position-paper-track-a-pilot-year-journey/),
for a minimum combined proceedings benchmark of
{int(neurips_coverage['official_2025_proceedings_min']):,}. The observed shortfall is
{int(neurips_coverage['dblp_shortfall_vs_official_2025_min']):,} records and DBLP coverage
is {float(neurips_coverage['dblp_coverage_vs_official_2025_min']):.1%}. Thus the anomalous
{float(neurips_coverage['growth_rate_2024_2025']):+.1%} 2024–2025 growth cannot be
interpreted as true NeurIPS growth. The precise cause is not identified here, but
upstream indexing incompleteness is confirmed rather than merely inferred from the
growth rate. By contrast, the 2024 DBLP roster has
{float(neurips_coverage['dblp_coverage_vs_official_2024_min']):.1%} coverage against
the official 4,497-paper combined benchmark, so 2024 is a defensible post-only
sensitivity year.

{markdown_table(coverage_report)}

We therefore repeat the post comparison using 2024 only. Every venue moves in the
same or stronger direction: ICLR, ICML, and NeurIPS show larger positive changes from
2022, while AAAI's negative change shrinks to less than one percentage point.

{markdown_table(post_2024_sensitivity)}

The older 2018–2022 pattern can still be summarized as "a wider door, the same gate":
more newcomer proceedings papers, but even faster growth of total proceedings papers
and larger teams. It should not be projected into the later period. The safer
post-2022 claim is that newcomer-share erosion weakens. In the unadjusted 2024–2025
mean AAAI appears to remain an exception, but its change is less than one percentage
point when post is restricted to 2024. The proceedings panel still cannot answer
whether newcomers submitted more often or were rejected more often; only ICLR can
decompose the funnel.

For auditability, the older pre/post-average contrast is retained below but is not
the headline comparison.

{markdown_table(changes)}

## Headline 2: ICLR newcomer penalty narrows in full-lookback cycles

In the full-lookback ICLR submission window ({first_full_year}–{int(iclr_focus['cycle'].max())}),
the first-author observed-newcomer review-score penalty moves from
{float(focus_start['review_score_z_gap']):+.3f} to
{float(focus_end['review_score_z_gap']):+.3f}, a {score_reduction_pct:.1f}% smaller
absolute z-score gap. The conditional acceptance-rate gap moves from
{100 * float(focus_start['newcomer_acceptance_gap']):+.1f} pp to
{100 * float(focus_end['newcomer_acceptance_gap']):+.1f} pp, a
{acceptance_reduction_pct:.1f}% smaller absolute gap.

This is a trend, not a discontinuity. ICLR 2023's full-paper deadline preceded the
public ChatGPT shock, and the gap had already narrowed by 2023; placebo timing and
pre-trend checks are mandatory before any LLM-era interpretation. The changes are not
monotone: the acceptance gap widens again from 2024 to 2025, while the score gap is
nearly unchanged. "Narrowing followed by a plateau or partial rebound" is safer than
claiming continuous improvement.

{markdown_table(iclr_focus)}

## Robustness: withdrawals as non-acceptances

Withdrawals are a serious selection issue because they rise over time and are
consistently newcomer-heavy. The audit below reports all submissions, including desk
rejects, only to measure withdrawal rates and composition.

{markdown_table(withdrawal_report)}

The ITT robustness keeps the main desk-reject exclusion but adds withdrawals as
non-acceptances. Score gaps are z-standardized within cycle using all observed review
scores among valid decisions plus withdrawals. The conclusion survives: the ITT score
penalty moves from {float(itt_start['itt_review_score_z_gap']):+.3f} to
{float(itt_end['itt_review_score_z_gap']):+.3f}, a {itt_score_reduction_pct:.1f}%
smaller absolute gap.

{markdown_table(withdrawal_itt)}

## Proceedings-paper annual panel

The machine-readable annual CSV retains `author_output_hhi` for auditability, but it
is omitted here because values are near zero and not informative in this pilot.

{markdown_table(accepted_report)}

## Proceedings-paper 2022–2025 diagnostic window

The raw 2022–2025 endpoints are nearly flat in ICLR, ICML, and NeurIPS and lower in
AAAI. This endpoint table is secondary: NeurIPS 2025 is coverage-incomplete, and the
2024-only sensitivity reduces AAAI's change to less than one percentage point. The
paired diagnostics prevent the older pre/post-average contrast from being interpreted
as a post-LLM decline.

{markdown_table(recent_accepted)}

## ICLR submission-to-decision funnel

The table below keeps all analysis years for transparency. Use {first_full_year}–2025
for the main ICLR newcomer-share, acceptance-gap, and review-score-gap summaries;
use 2018–2021 only as left-censored diagnostics.

{markdown_table(iclr)}

## Interpretation limits

1. DBLP contains accepted papers only; it cannot identify submission propensity or
   acceptance gaps outside ICLR.
2. The DBLP venue stream is a proceedings roster, not a harmonized main-track
   acceptance registry. This matters especially for AAAI, whose proceedings include
   IAAI, EAAI, and other program categories. Main-track filtering or an AAAI-excluded
   sensitivity analysis is required before treating cross-year counts as directly
   comparable main-track acceptances.
3. The live DBLP NeurIPS 2025 roster contains only 4,573 records versus an official
   minimum proceedings benchmark of 5,493 (5,290 main, 163 Datasets & Benchmarks,
   40 Position). The 2025 NeurIPS row is coverage-incomplete; the 2024-only post
   comparison is mandatory and missing author records are not imputed.
4. ICLR observed-newcomer levels are left-censored before {first_full_year}. Early
   levels, especially 2018, are mechanically inflated and measure first observed
   appearance in the public archive, not true career-first entry. This warning does
   not apply to the DBLP accepted-panel five-year lookback, which uses 2013–2017
   history for 2018.
5. The ICLR primary observed-newcomer definition is five-year rolling normalized-name
   submission history, not lifetime history. Name matching can merge homonyms or
   split name variants, so author-profile linkage must be audited before inferential
   use. The ID-assisted bridge is sensitivity-only because incomplete bridges can
   create a key-boundary artifact after OpenReview IDs become common.
6. Withdrawals are not random attrition. They are included as non-acceptances in the
   ITT robustness table and should be discussed explicitly in any manuscript.
7. Country, institution type, and prior field are intentionally absent from headline
   claims until their linkage and coverage audits pass.
8. `mean_review_score_raw` is the paper-level mean of available review scores. Score
   scales, rubrics, and reviewer composition can differ across cycles, so raw yearly
   means must not be interpreted as substantive trends. `mean_review_score_z` and the
   newcomer–returning gap are standardized within each cycle's main valid-decision
   sample and remain descriptive.
9. Affiliation-sector trends should be reported first-author-first. All-author sector
   rows are robustness diagnostics because all-author affiliation coverage changes
   more strongly over time.
10. A title keyword is only a sensitivity flag for the LLM topic boom, never evidence
   that a paper used an LLM.
11. No causal claim should be made from a raw before/after comparison.
"""
    (output_dir / "initial_findings.md").write_text(report, encoding="utf-8")
    (output_dir / "iclr_schema_audit.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (output_dir / "accepted_panel_audit.json").write_text(
        json.dumps(accepted_audit, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Wrote results to {output_dir}")


if __name__ == "__main__":
    main()
