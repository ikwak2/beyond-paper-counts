# Supplementary reproducibility materials

**Beyond Paper Counts: Measuring Representation, Entry, and Persistence at ICML and NeurIPS, 2018–2024**  
Jungchan Ryu and Il-Youp Kwak

## Contents and sources

`archive_v1.0.2/` contains the 173 files of the original release, preserved byte for byte, including its README, licences, source code and provenance manifests. Materials outside that directory accompany the manuscript and are distinct from the archived release.

`data/` contains aggregate country comparisons, author-check tables and provenance records. `figures/` contains the current vector figures and retained vector inputs required by the rendering utilities. `scripts/` contains downstream summary, rendering and verification utilities. `provenance_source/top_ai_entry/` retains code needed to document the initial identity and cohort construction.

The separately supplied `Additional_file_2.zip` and `Supplementary_Data_country_comparison.zip` contain machine-readable supplementary tables and country comparisons, respectively. This bundle supplements those files.

In the Supplementary Information, [A] paths are relative to `archive_v1.0.2/` and [R] paths are relative to this bundle. `data/display_source_code_map.csv` maps each display to its data and calculation or rendering code. Archived numerical filename prefixes do not necessarily match current printed table numbers. Original script names are retained so that these paths remain traceable.

## Running the utilities

Install the versions listed in `requirements-figures.txt`. Commands for current Figures 2 and 4 (direct frozen-CSV rendering), Figure 5, and the retained Figure 3/S1 notation utility are documented in `REPRODUCTION.md`. The utilities write to an explicit output directory and do not refit the outcome models. Font subsetting preserves the rendered appearance while embedding only the required glyphs.

`figures/panel_labels_baseline_v5/` contains only the Figure 3 and S1 inputs used by `scripts/standardize_panel_labels_v5.py`. Current Figures 2 and 4 use the frozen-CSV renderer and require no manuscript-page vector inputs. Current validation records are under `verification/` and alongside the figures. `figures/figures_2_4_csv_validation.json` records source hashes, direct CSV/artist comparisons at 1e-9, visible-label-only pdfminer extraction, and absence of imported page forms. The file map distinguishes numerical calculation from copying, reconstructed rendering and vector editing.

`scripts/recover_vector_assets.py` is retained as a historical utility for multiple main and supplementary figures. The source manuscript PDFs required as its inputs are not distributed in this bundle and must be supplied separately. It does not generate the current Figures 2 and 4; use the frozen-CSV renderer for those figures.

## Reproducibility limits

The bundle supports downstream checks using frozen inputs and estimates. It does not independently reconstruct the full upstream author–paper–affiliation collection or validate all bibliographic identities. Linked person-level source records and some row-level local inputs are not redistributed.

The original collection execution commit, initial HTTP retrieval dates, independent manual identity-validation counts and official DBLP full-dump release identifier remain unestablished. A preserved timestamp or file hash alone does not establish an official DBLP release or identity accuracy. The original OpenAlex topic-linkage achieved-rate output and complete upstream SPECTER2 cache and immutable model revisions are not reconstructed. The 32 work-level specification results remain frozen outputs.

The original Figure S1 redraw program was not recovered. `scripts/revise_s1_axes.py` is a reconstructed renderer from the 176 frozen values; it verifies numerical content and layout rather than reproducing the unavailable program. Some original scripts retain local project paths and are provenance records rather than standalone commands. These limitations are also described in Supplementary Section S13.

## Integrity

`MANIFEST.csv` and `SHA256SUMS.txt` cover every other file in this bundle. The original 173-file archive, scientific input and result tables, sample definitions, estimates and inferential intervals are preserved. Current figure validation reports document the stated rendering checks; they do not establish that every historical scientific computation has been independently repeated.
