# Frozen country-comparison data

Generated from manuscript-cited public GitHub commit `9b8b962eddd87f7279504c3f59d8de34b230e90c`.
Source files:
- `supplement_table2_all_countries_2018_2024.csv`: 1,470 country-year records (210 countries x 7 years).
- `supplement_table2_all_countries_endpoints.csv`: 210 country endpoint records.

11-country selection: top ten by 2018 accepted credits, union top three by 2018 observed AI-output credits (ties retained; 11 in this frozen data). No endpoint-change selection.

All shares use **all observed country credits**, not the subtotal of the 11 selected countries. The accepted-paper numerator is conservative-mapping first-listed-author whole counting; the observed-AI denominator is all-author work-country whole counting. PRI is a ratio of these shares, not an acceptance rate. Undefined growth when 2018 credit is zero is left blank.

Files:
- `country_case_timeseries.csv` (77 rows): 11 selected countries x 7 years, including accepted/output credits, shares and PRI.
- `country_case_endpoints.csv` (11 rows): 2018/2024 endpoints, country credit growth, PRI.
- `country_all_timeseries.csv` (1,470 rows): full frozen annual primary specification.
- `country_all_endpoints.csv` (210 rows): all country endpoints plus derived growth/status.
- `country_annual_totals.csv` (7 rows): yearly denominators for accepted and AI-output credits.
- `country_selection.csv` (210 rows): reproducible baseline ranks/selection flag.

This data bundle is separate from `Additional_file_2.zip`, which must also be sourced from the **existing frozen archive** or project original. This script neither rebuilds nor fabricates that original supplementary package.
