# Added descriptive diagnostics

These CSVs are newly reconstructed descriptive outputs; they are not model estimates or new fits.

- `rq3_observed_outcomes_by_coauthor_history.csv`: `recent_coauthor_history` is 0/1 for absence/presence of a coauthor with prior-five-cycle four-venue history; `outcome` preserves the archived exact-t+2 coding; `n` is the observed category count; `group_n` is the history-group denominator; `percent = 100*n/group_n`. Three mutually exclusive categories sum to each group total.
- `rq3_group_descriptives.csv`: `n`, mean, sample SD (n−1 denominator), median, Q25/Q75 (pandas linear interpolation), minimum and maximum of per-entrant mean entry-team size. Team size is averaged over qualifying entry papers and need not be integer.
- `rq3_team_size_overlap.csv`: the intersection of the two observed team-size ranges, and within/below/above counts by history group. It describes only this covariate; it does not establish common support in all model covariates.
- `cohort_sample_flow.csv`: retained entrant counts by named filter stage. These stages are not mutually exclusive rows.
- `country_coverage_by_year.csv`: year and overall 2018–2024 totals; roster papers; country-resolved papers; unresolved papers; whole country credits; and `coverage_percent = 100*country_resolved_papers/roster_papers`. The conservative first-listed-author mapping is used. Full credits count distinct observed countries; summed fractional credits count resolved papers.
- `author_review_diagnostics_provenance.json`: original-input hashes, new aggregate-source hash, generator hash, output hashes, environment and limitations. No date/version of an absent original generator is inferred.
