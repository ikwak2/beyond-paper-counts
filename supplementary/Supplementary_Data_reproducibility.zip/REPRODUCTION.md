# Figure inputs, rendering and validation

Run these commands from the extracted bundle root after installing `requirements-figures.txt`. Use fresh output directories to keep the supplied files intact.

## Figures 2 and 4 directly from frozen CSVs

```bash
python scripts/render_figures_2_4_from_csv.py --bundle-root . --output-dir outputs/figures_2_4
```

This renderer reads the frozen panel-A pooled PRI and panel-B four-group PRI tables, the denominator-missingness bounds, 249 calibration coordinates, calibration display values and the annual distance table. It never imports or crops manuscript pages. Every plotted numerical array is compared with its CSV source with `atol=1e-9, rtol=0`. It checks that pdfminer extracts only visible label characters, that the specified stale-text patterns are absent and that any native marker Form XObjects contain no text or nested imported page. Fonts are subset immediately before saving, with zero pixel differences at 200 dpi. The output JSON files retain all checked arrays and source hashes.

## Retained Figure 3 and S1 notation utility

```bash
python scripts/standardize_panel_labels_v5.py --output-dir outputs/vector_figures --qa-dir outputs/vector_validation
```

The default input directory, `figures/panel_labels_baseline_v5/`, contains only Figure 3 and Supplementary Figure S1. The utility edits their panel letters and Figure 3's thousands separator in retained vector inputs, checks the plotted paths/coordinates to 0.001 pt and zero pixel differences outside the intended edits at 216 dpi, and subsets fonts. It does not overwrite current Figures 2 or 4; those must use the direct CSV renderer above.

## Figure 5 from frozen estimates

```bash
python scripts/render_figure5_v5.py --bundle-root . --output-dir outputs/figure5
```

The utility reads `archive_v1.0.2/data/distance/rq3_exact_plus2_probabilities.csv` and `rq3_exact_plus2_contrasts.csv`. It selects `semantic_primary`, and for panel b, `experienced_minus_no_experienced`. It plots 12 standardized pathway probabilities and six contrasts without fitting a model or running a bootstrap. Panel b spans −19 to +15 percentage points. The JSON output retains the plotted input rows and checks interval containment, text containment, separation of row labels and separation of the legend from interval caps and markers.

## Other sources and checks

`data/display_source_code_map.csv` identifies the calculation and rendering paths for every display, including the reconstructed S1 renderer and country-summary builders. `scripts/recover_vector_assets.py` documents historical recovery of several main and supplementary figures; its source manuscript PDF inputs are not distributed and must be supplied separately. It is not needed by the current Figures 2/4 renderer.

`scripts/reproduce_submission.py` checks frozen summaries and retained rendering operations, using the direct CSV renderer for Figures 2 and 4. It does not recreate all current typography. Use the commands above for current Figures 2/4, Figure 5 and the Figure 3/S1 notation utility.

Current validation outputs refer to these stated operations. They do not establish full upstream collection reproducibility or independent replication of every model estimate. Source-code and input availability limits are detailed in the bundle README and Supplementary Section S13.
